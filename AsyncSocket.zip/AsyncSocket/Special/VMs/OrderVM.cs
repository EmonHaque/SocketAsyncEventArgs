﻿using Data;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Client.VMs
{
    public class OrderVM : INotifyPropertyChanged, IDataErrorInfo
    {

        int orderType;
        string price, quantity, partyCode;
        static int itemCode;

        static IEnumerable<DisplayOrder> buys, sells;
        static FHLLV fhllv;

        MessageHeader header;
        public static int ItemCode {
            get => itemCode;
            set {
                itemCode = value;
                Buys = GetOrders(ClientCode.BuyOrders).OrderByDescending(x => x.Price);
                Sells = GetOrders(ClientCode.SellOrders).OrderBy(x => x.Price);
                var list = ClientCode.ExecutedOrders.Where(x => x.ItemCode == ItemCode);
                if (list.Count() > 0) SetFHLLV(list);
                else ZeroFHLLV();
                OnStaticPropertyChanged();
            }
        }

        public int OrderType { get => orderType; set { orderType = value; OnPropertyChanged(); } }
        public string Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }
        public string Price { get => price; set { price = value; OnPropertyChanged(); } }
        public string PartyCode { get => partyCode; set { partyCode = value; OnPropertyChanged(); } }
        public Command Submit { get; set; }
        public static IEnumerable<DisplayOrder> Buys { get => buys; set { buys = value; OnStaticPropertyChanged(); } }
        public static IEnumerable<DisplayOrder> Sells { get => sells; set { sells = value; OnStaticPropertyChanged(); } }
        public static FHLLV Fhllv { get => fhllv; set { fhllv = value; OnStaticPropertyChanged(); } }

        public OrderVM()
        {
            Fhllv = new FHLLV();
            header = new MessageHeader() { Type = Message.Trade };
            ClientCode.BuyOrders.CollectionChanged += (o, e) => UpdateOrderLists(ClientCode.BuyOrders, e, Data.OrderType.Buy);
            ClientCode.SellOrders.CollectionChanged += (o, e) => UpdateOrderLists(ClientCode.SellOrders, e, Data.OrderType.Sell);
            ClientCode.ExecutedOrders.CollectionChanged += (o, e) => UpdateFHLLV(e);
            Submit = new Command(SubmitOrder, (o) => Errors.Count == 0);
        }

        void UpdateFHLLV(NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                var order = e.NewItems[0] as AllOrder;
                if (order.ItemCode == ItemCode)
                {
                    var list = ClientCode.ExecutedOrders.Where(x => x.ItemCode == ItemCode);
                    SetFHLLV(list);
                }
            }
        }

        static void SetFHLLV(IEnumerable<AllOrder> list)
        {
            Fhllv.First = list.Last().Price;
            Fhllv.High = list.Max(x => x.Price);
            Fhllv.Low = list.Min(x => x.Price);
            Fhllv.Last = list.First().Price;
            Fhllv.Volume = list.Sum(x => x.QtyTraded);
        }

        static void ZeroFHLLV()
        {
            Fhllv.First = Fhllv.High = Fhllv.Low = Fhllv.Last = 0;
            Fhllv.Volume = 0;
        }

        void UpdateOrderLists(AsyncObsetion<AllOrder> orderList, NotifyCollectionChangedEventArgs e, OrderType type)
        {
            if (e.Action != NotifyCollectionChangedAction.Reset)
            {
                var order = e.Action == NotifyCollectionChangedAction.Add ? e.NewItems[0] as AllOrder : e.OldItems[0] as AllOrder;
                if (order.ItemCode == ItemCode)
                {
                    switch (type)
                    {
                        case Data.OrderType.Buy: Buys = GetOrders(ClientCode.BuyOrders).OrderByDescending(x => x.Price); break;
                        case Data.OrderType.Sell: Sells = GetOrders(ClientCode.SellOrders).OrderBy(x => x.Price); break;
                    }
                }
            }
        }

        static IEnumerable<DisplayOrder> GetOrders(AsyncObsetion<AllOrder> order) =>
            order.Where(x => x.ItemCode == ItemCode)
            .GroupBy(x => x.Price)
            .Select(x => new DisplayOrder { Price = x.Key, NoOfOrder = x.Count(), Quantity = x.Sum(x => x.Quantity) });

        void SubmitOrder(object obj)
        {
            var order = new AllOrderStruct()
            {
                Action = Data.Action.Add,
                BrokerName = ClientCode.BrokerName,
                ItemCode = ItemCode,
                OrderType = OrderType == 0 ? Data.OrderType.Buy : Data.OrderType.Sell,
                PartyCode = Convert.ToInt32(PartyCode),
                Price = Convert.ToSingle(Price),
                Quantity = Convert.ToInt32(Quantity)
            };
            ClientCode.sendArgs.AcceptSocket.Send(PacMan<MessageHeader>.Pack(header));
            ClientCode.sendArgs.AcceptSocket.Send(PacMan<AllOrderStruct>.Pack(order));
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion

        #region IDataErrorInfo
        public string Error => null;

        List<string> errors;
        public List<string> Errors {
            get {
                errors = new List<string>();
                if (!String.IsNullOrWhiteSpace(this["PartyCode"])) errors.Add(this["PartyCode"]);
                if (!String.IsNullOrWhiteSpace(this["Quantity"])) errors.Add(this["Quantity"]);
                if (!String.IsNullOrWhiteSpace(this["Price"])) errors.Add(this["Price"]);
                return errors;
            }
        }

        public string this[string columnName] {
            get {
                string error = string.Empty;
                int x; float y;
                if (columnName == "PartyCode") { if (!int.TryParse(PartyCode, out x)) error = "Invalid"; }
                else if (columnName == "Quantity") { if (!int.TryParse(Quantity, out x)) error = "Invalid"; }
                else if (columnName == "Price") { if (!float.TryParse(Price, out y)) error = "Invalid"; }
                return error;
            }
        }
        #endregion
    }
}
