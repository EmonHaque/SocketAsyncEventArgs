﻿using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Server
{
    public class ServerCode : INotifyPropertyChanged
    {
        Socket server;
        bool isListening;
        string status;
        int orderNo = 1;
        int transactionNo = 1;

        FileServer updateServer;

        public ICommand Start { get; set; }
        public ICommand Stop { get; set; }
        public bool IsListening { get => isListening; set { isListening = value; OnPropertyChanged(); } }
        public string Status { get => status; set { status = value; OnPropertyChanged(); } }
        public AsyncObsetion<Client> Clients { get; set; }
        public FileServer UpdateServer { get => updateServer; set { updateServer = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler PropertyChanged;

        public AsyncObsetion<Item> Items = new AsyncObsetion<Item>();
        public AsyncObsetion<AllOrder> BuyOrders = new AsyncObsetion<AllOrder>();
        public AsyncObsetion<AllOrder> SellOrders = new AsyncObsetion<AllOrder>();
        public AsyncObsetion<AllOrder> ExecutedOrders = new AsyncObsetion<AllOrder>();
        public AsyncObsetion<DisplayNews> MarketNews = new AsyncObsetion<DisplayNews>();

        public ServerCode()
        {
            UpdateServer = new FileServer();
            StartServer(null);
            Task.Run(() => UpdateServer.StartServer(null));

            for (int i = 0; i < 10; i++)
            {
                Items.Add(new Item() { Id = i + 1, Name = "Item " + (i + 1) });
            }

            Clients = new AsyncObsetion<Client>();
            Start = new Command(StartServer, (o) => !IsListening);
            Stop = new Command(StopServer, (o) => IsListening);
           
        }

        void StartServer(object obj)
        {
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(new IPEndPoint(0, Constants.tradePort));
            server.Listen(0);
            IsListening = true;
            Status = "Listening";
            Accept();
        }

        void Accept()
        {
            var arg = new SocketAsyncEventArgs();
            arg.Completed += Accepted;
            if (!server.AcceptAsync(arg)) Accepted(null, arg);
        }

        void Accepted(object sender, SocketAsyncEventArgs e)
        {
            if(e.SocketError == SocketError.Success)
            {
                e.Completed -= Accepted;
                e.Completed += CheckInfo;
                SetBuffer(e, Constants.infoBuffLength);
                bool checkedInfo = e.AcceptSocket.ReceiveAsync(e);
                if (!checkedInfo) CheckInfo(null, e);
                Accept();
            }
            else if(e.SocketError == SocketError.OperationAborted)
            {
                e.Dispose();
                StopServer(null);
            }
        }

        void CheckInfo(object sender, SocketAsyncEventArgs e)
        {
            lock (Clients)
            {
                e.Completed -= CheckInfo;
                var info = PacMan<SockInfo>.Unpack(e.Buffer);
                var c = Clients.FirstOrDefault(x => x.Name == info.Name);
                if (c == null)
                {
                    c = new Client();
                    c.Name = info.Name;
                    Clients.Add(c);
                }

                if (info.RecvArg)
                {
                    c.SendArgs = e;
                    c.SendArgs.SetBuffer(null);
                    c.SendArgs.Completed += Sent;
                    SendLists(c);
                }
                else
                {
                    c.RecvArgs = e;
                    FixedBuffers token = new FixedBuffers();
                    c.RecvArgs.UserToken = token;
                    c.RecvArgs.SetBuffer(token.HeaderBuffer, 0, Constants.messageHeaderLength);
                    c.RecvArgs.Completed += Received;
                    if (!c.RecvArgs.AcceptSocket.ReceiveAsync(c.RecvArgs)) Received(null, c.RecvArgs);
                }
            }
        }

        void SendLists(Client c)
        {
            bool hasBuy = BuyOrders.Count > 0;
            bool hasSell = SellOrders.Count > 0;
            bool hasExec = ExecutedOrders.Count > 0;
            bool hasNews = MarketNews.Count > 0;

            var header = new HeaderStruct()
            {
                HasBuy = hasBuy,
                HasSell = hasSell,
                HasExecuted = hasExec,
                HasNews = hasNews,

                ItemSize = Items.Count * Constants.itemSize,
                BuySize = BuyOrders.Count * Constants.orderSize,
                SellSize = SellOrders.Count * Constants.orderSize,
                ExecutedSize = ExecutedOrders.Count * Constants.orderSize,
                NewsSize = MarketNews.Count * Constants.newsSize,
            };

            var array = new List<ArraySegment<byte>>();
            array.Add(PacMan<HeaderStruct>.Pack(header));

            foreach (var item in Items)
            {
                array.Add(PacMan<ItemStruct>.Pack(new ItemStruct()
                {
                    Id = item.Id,
                    Name = item.Name
                }));
            }

            if (hasBuy) PackOrder(BuyOrders, array);
            if (hasSell) PackOrder(SellOrders, array);
            if (hasExec) PackOrder(ExecutedOrders, array);
            if (hasNews) PackNews(MarketNews, array);
            c.SendArgs.AcceptSocket.Send(array);
        }

        void PackNews(AsyncObsetion<DisplayNews> marketNews, List<ArraySegment<byte>> array)
        {
            foreach (var news in MarketNews)
            {
                array.Add(PacMan<News>.Pack(new News()
                {
                    Time = news.Time,
                    ItemCode = news.ItemCode,
                    Feed = news.Feed
                }));
            }
        }

        void PackOrder(AsyncObsetion<AllOrder> orderType, List<ArraySegment<byte>> array)
        {
            foreach (var order in orderType)
            {
                array.Add(PacMan<AllOrderStruct>.Pack(new AllOrderStruct()
                {
                    TransactionNo = order.TransactionNo,
                    BrokerBought = order.BrokerBought,
                    BrokerName = order.BrokerName,
                    BrokerSold = order.BrokerSold,
                    Action = order.Action,
                    ItemCode = order.ItemCode,
                    BuyOrderNo = order.BuyOrderNo,
                    SellOrderNo = order.SellOrderNo,
                    OrderType = order.OrderType,
                    PartyBought = order.PartyBought,
                    PartyCode = order.PartyCode,
                    PartySold = order.PartySold,
                    Price = order.Price,
                    QtyTraded = order.QtyTraded,
                    Quantity = order.Quantity,
                }));
            }
        }

        void Received(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                var token = e.UserToken as FixedBuffers;
                var data = PacMan<MessageHeader>.Unpack(e.Buffer);
                byte[] array = null;
                if (data.Type == Message.News)
                {
                    SetBuffer(e, data.Size);
                    e.AcceptSocket.Receive(e.Buffer);
                    array = e.Buffer.ToArray();
                    Task.Run(() => BroadcastNews(array));
                }
                else
                {
                    e.SetBuffer(token.OrderBuffer, 0, Constants.orderSize);
                    e.AcceptSocket.Receive(e.Buffer);
                    var order = PacMan<AllOrderStruct>.Unpack(e.Buffer);
                    Task.Run(() => ProcessAndSend(order));
                }
                e.SetBuffer(token.HeaderBuffer, 0, Constants.messageHeaderLength);

                if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
            }
            else if (e.SocketError == SocketError.OperationAborted) StopServer(null);
            else RemoveClient(e);
        }

        void ProcessAndSend(AllOrderStruct order)
        {
            lock (SellOrders)
            {
                lock (BuyOrders)
                {
                    var orderList = order.OrderType == OrderType.Buy ? BuyOrders : SellOrders;

                    switch (order.Action)
                    {
                        case Data.Action.Delete: DeleteIfExistis(orderList, order); break;
                        case Data.Action.Modify: if (IsReady4Execution(orderList, order)) Execute(Match4Execution(order), order); break;
                        case Data.Action.Add:
                            if (Match4Execution(order).Count() > 0) Execute(Match4Execution(order), order);
                            else
                            {
                                AddNewOrder(orderList, order);
                                orderNo++;
                            }
                            break;
                    }
                }
            }
        }

        void Execute(IEnumerable<AllOrder> matched, AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var matchedList = buyOrder ? SellOrders : BuyOrders;
            var available = matched.Sum(x => x.Quantity);
            var ordered = order.Quantity;
            matched = buyOrder ? matched.OrderBy(x => x.Price).ThenBy(x => x.SellOrderNo)
                               : matched.OrderByDescending(x => x.Price).ThenBy(x => x.BuyOrderNo);

            if (order.Action == Data.Action.Add)
            {
                if (buyOrder) order.BuyOrderNo = orderNo;
                else order.SellOrderNo = orderNo;
            }

            foreach (var match in matched)
            {
                match.TransactionNo = transactionNo;

                match.Action = Data.Action.Execute;
                match.BrokerBought = buyOrder ? order.BrokerName : match.BrokerName;
                match.BrokerSold = buyOrder ? match.BrokerName : order.BrokerName;
                match.PartyBought = buyOrder ? order.PartyCode : match.PartyCode;
                match.PartySold = buyOrder ? match.PartyCode : order.PartyCode;

                if (buyOrder) match.BuyOrderNo = order.BuyOrderNo;
                else match.SellOrderNo = order.SellOrderNo;

                if (match.Quantity <= ordered)
                {
                    match.ExType = ExecutionType.Full;
                    match.QtyTraded = match.Quantity;
                    matchedList.Remove(match);
                }
                else
                {
                    match.ExType = ExecutionType.Partial;
                    match.QtyTraded = ordered;
                    var index = matchedList.IndexOf(match);
                    match.Quantity -= match.QtyTraded;
                    matchedList[index] = match;
                }
                ExecutedOrders.Add(match.Clone() as AllOrder);
                BroadcastOrder(OrderStruct4mClass(match));

                available -= match.QtyTraded;
                ordered -= match.QtyTraded;
                if (available <= 0 || ordered <= 0) break;
            }
            transactionNo++;

            var list = buyOrder ? BuyOrders : SellOrders;
            var o = buyOrder ? list.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : list.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();

            if (ordered > 0)
            {
                order.Quantity = ordered - available;
                switch (order.Action)
                {
                    case Data.Action.Add:
                        order.Action = Data.Action.Add;
                        AddNewOrder(list, order);
                        orderNo++;
                        break;

                    case Data.Action.Modify:
                        order.Action = Data.Action.Modify;
                        var index = list.IndexOf(o);
                        o.Quantity = order.Quantity;
                        o.Price = order.Price;
                        list[index] = o;
                        BroadcastOrder(order);
                        break;
                }
            }
            else
            {
                switch (order.Action)
                {
                    case Data.Action.Add: orderNo++; break;
                    case Data.Action.Modify:
                        list.Remove(o);
                        order.Action = Data.Action.Delete;
                        BroadcastOrder(order);
                        break;
                }
            }

        }

        AllOrderStruct OrderStruct4mClass(AllOrder match)
        {
            var orderStruct = new AllOrderStruct()
            {
                SellOrderNo = match.SellOrderNo,
                Action = match.Action,
                BrokerBought = match.BrokerBought,
                BrokerName = match.BrokerName,
                BrokerSold = match.BrokerSold,
                BuyOrderNo = match.BuyOrderNo,
                ExType = match.ExType,
                ItemCode = match.ItemCode,
                OrderType = match.OrderType,
                PartyBought = match.PartyBought,
                PartyCode = match.PartyCode,
                PartySold = match.PartySold,
                Price = match.Price,
                QtyTraded = match.QtyTraded,
                Quantity = match.Quantity,
                TransactionNo = match.TransactionNo
            };
            return orderStruct;
        }

        bool IsReady4Execution(AsyncObsetion<AllOrder> orderList, AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var o = buyOrder ? orderList.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : orderList.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();

            if (o != null)
            {
                var index = orderList.IndexOf(o);
                o.Quantity = order.Quantity;
                o.Price = order.Price;
                orderList[index] = o;

                if (Match4Execution(order).Count() > 0) return true;
                else
                {
                    BroadcastOrder(order);
                    return false;
                }
            }
            else return false;
        }

        IEnumerable<AllOrder> Match4Execution(AllOrderStruct order)
        {
            var match = order.OrderType == OrderType.Buy ? SellOrders.Where(x => x.ItemCode == order.ItemCode && x.Price <= order.Price)
                                                      : BuyOrders.Where(x => x.ItemCode == order.ItemCode && x.Price >= order.Price);
            return match;
        }

        void DeleteIfExistis(AsyncObsetion<AllOrder> orderList, AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var o = buyOrder ? orderList.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : orderList.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();
            if (o != null)
            {
                orderList.Remove(o);
                BroadcastOrder(order);
            }
        }

        void AddNewOrder(AsyncObsetion<AllOrder> orderList, AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;

            var order2Add = new AllOrder();
            order2Add.Action = order.Action;
            order2Add.OrderType = order.OrderType;
            order2Add.ItemCode = order.ItemCode;
            order2Add.BrokerName = order.BrokerName;
            order2Add.PartyCode = order.PartyCode;
            order2Add.Price = order.Price;
            order2Add.Quantity = order.Quantity;
            order2Add.BuyOrderNo = order.BuyOrderNo = buyOrder ? orderNo : 0;
            order2Add.SellOrderNo = order.SellOrderNo = buyOrder ? 0 : orderNo;

            orderList.Add(order2Add);
            BroadcastOrder(order);
        }

        void BroadcastOrder(AllOrderStruct order)
        {
            Parallel.ForEach(Clients, c =>
            {
                try
                {
                    c.SendArgs.AcceptSocket.Send(PacMan<MessageHeader>.Pack(new MessageHeader() { Type = Message.Trade }));
                    c.SendArgs.AcceptSocket.Send(PacMan<AllOrderStruct>.Pack(order));
                }
                catch (Exception) { }
            });
        }

        void BroadcastNews(byte[] array)
        {
            var n = PacMan<News>.Unpack(array);
            MarketNews.Add(new DisplayNews()
            {
                Time = n.Time,
                ItemCode = n.ItemCode,
                Feed = n.Feed
            });

            Parallel.ForEach(Clients, c =>
            {
                try
                {
                    c.SendArgs.AcceptSocket.Send(PacMan<MessageHeader>.Pack(new MessageHeader() { Type = Message.News, Size = array.Length }));
                    c.SendArgs.AcceptSocket.Send(array);
                }
                catch (Exception) { }
            });
        }

        void Sent(object s, SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {

            }
            else RemoveClient(e);
        }

        void RemoveClient(SocketAsyncEventArgs e)
        {
            var c = Clients.FirstOrDefault(x => x.SendArgs == e || x.RecvArgs == e);
            Cleanup(c);
            Clients.Remove(c);
        }

        void StopServer(object obj)
        {
            DisposeClients();
            server.Close();
            server.Dispose();
            IsListening = false;
            Status = "Start Server";
        }

        void DisposeClients()
        {
            if (Clients.Count > 0)
            {
                foreach (var c in Clients) Cleanup(c);
                Clients.Clear();
            }
        }

        void Cleanup(Client c)
        {
            if (c.SendArgs != null)
            {
                c.SendArgs.AcceptSocket.Close();
                c.SendArgs.AcceptSocket.Dispose();
                c.SendArgs.Dispose();
            }

            if (c.RecvArgs != null)
            {
                c.RecvArgs.AcceptSocket.Close();
                c.RecvArgs.AcceptSocket.Dispose();
                c.RecvArgs.Dispose();
            }
        }

        void SetBuffer(SocketAsyncEventArgs e, int length) => e.SetBuffer(new byte[length], 0, length);

        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class Client
    {
        public string Name { get; set; }
        public SocketAsyncEventArgs SendArgs { get; set; }
        public SocketAsyncEventArgs RecvArgs { get; set; }
    }

    public class FixedBuffers
    {
        public byte[] OrderBuffer { get; set; }
        public byte[] HeaderBuffer { get; set; }

        public FixedBuffers()
        {
            OrderBuffer = new byte[Constants.orderSize];
            HeaderBuffer = new byte[Constants.messageHeaderLength];
        }
    }

    public class Command : ICommand
    {
        Action<object> Do;
        Func<object, bool> CanDo;

        public Command(Action<object> Do, Func<object, bool> CanDo)
        {
            this.CanDo = CanDo;
            this.Do = Do;
            CommandManager.RequerySuggested += (o, e) => Changed();
        }

        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter) => CanDo(parameter);
        public void Execute(object parameter) => Do(parameter);
        public void Changed() => CanExecuteChanged?.Invoke(null, EventArgs.Empty);
    }
}
