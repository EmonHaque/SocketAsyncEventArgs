﻿using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;

namespace Server
{
    public class FileServer : INotifyPropertyChanged
    {
        Socket fileServer;
        bool isListening;
        string status;
        int generalLoad, specialLoad;
        string generalPath = @"C:\Users\Emon\Desktop\OrdinaryUpdate";
        //string specialPath = @"C:\Users\Emon\Desktop\SpecialUpdate";
        List<UpdatedFiles> generalFiles, specialFiles;

        public Command Start { get; set; }
        public Command Stop { get; set; }
        public bool IsListening { get => isListening; set { isListening = value; OnPropertyChanged(); } }
        public string Status { get => status; set { status = value; OnPropertyChanged(); } }
        public AsyncObsetion<UpdateClient> Clients { get; set; }

        public FileServer()
        {
            generalFiles = new List<UpdatedFiles>();
            specialFiles = new List<UpdatedFiles>();
            ListFiles();
            Clients = new AsyncObsetion<UpdateClient>();
            Start = new Command(StartServer, (o) => !IsListening);
            Stop = new Command(StopServer, (o) => IsListening);
        }

        void ListFiles()
        {
            GetFiles(generalFiles, generalPath, ref generalLoad);
            //GetFiles(specialFiles, specialPath, ref specialLoad);
        }

        void GetFiles(List<UpdatedFiles> list, string path, ref int load)
        {
            var dir = Directory.GetFiles(path);
            foreach (var file in dir)
            {
                var content = File.ReadAllBytes(file);
                var length = content.Length;
                var info = new FileStruct() { Name = file.Substring(file.LastIndexOf("\\") + 1), Size = length };
                list.Add(new UpdatedFiles()
                {
                    Info = info,
                    Content = content
                });
                load += length;
            }
        }

        public void StartServer(object obj)
        {
            fileServer = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            fileServer.Bind(new IPEndPoint(0, Constants.filePort));
            fileServer.Listen(0);
            IsListening = true;
            Status = "Listening";
            Accept();
        }

        void Accept()
        {
            var e = new SocketAsyncEventArgs();
            e.Completed += Accepted;
            if (!fileServer.AcceptAsync(e)) Accepted(null, e);
        }

        void Accepted(object sender, SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {
                e.Completed -= Accepted;
                e.Completed += Received;
                e.SetBuffer(new byte[16], 0, 16);
                if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
                Accept();
            }
            else if (e.SocketError == SocketError.OperationAborted)
            {
                e.Dispose();
                StopServer(null);
            }
        }

        void Received(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                var client = PacMan<UpdateClientStruct>.Unpack(e.Buffer);

                Clients.Add(new UpdateClient()
                {
                    Client = e,
                    Name = client.Name,
                    Type = client.Type
                });
                var load = client.Type == ClientType.General ? generalLoad : specialLoad;
                var files = client.Type == ClientType.General ? generalFiles : specialFiles;

                var initInfo = new FileStruct() { Name = "TotalSize", Size = load };
                try { e.AcceptSocket.Send(PacMan<FileStruct>.Pack(initInfo)); }
                catch (Exception) { Cleanup(e); }

                foreach (var file in files)
                {
                    try
                    {
                        var info = PacMan<FileStruct>.Pack(file.Info);
                        e.AcceptSocket.Send(new List<ArraySegment<byte>>() { info, file.Content });
                    }
                    catch (Exception) { RemoveClient(e); return; }
                }
                var eof = PacMan<FileStruct>.Pack(new FileStruct() { Name = "EOF" });
                e.AcceptSocket.Send(eof);
                if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
            }
            else if (e.SocketError == SocketError.OperationAborted) StopServer(null);
            else RemoveClient(e);
        }

        void RemoveClient(SocketAsyncEventArgs e)
        {
            if(Clients.Count > 0)
            {
                var c = Clients.First(x => x.Client == e);
                Cleanup(c.Client);
                Clients.Remove(c);
            }
        }

        public void StopServer(object obj)
        {
           if(fileServer != null)
            {
                DisposeClients();
                fileServer.Close();
                fileServer.Dispose();
                IsListening = false;
                Status = "Start Server";
            }
        }

        void DisposeClients()
        {
            if (Clients.Count > 0)
            {
                foreach (var c in Clients) Cleanup(c.Client);
                Clients.Clear();
            }
        }

        void Cleanup(SocketAsyncEventArgs c)
        {
            c.AcceptSocket.Close();
            c.AcceptSocket.Dispose();
            c.Dispose();
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class UpdateClient
    {
        public ClientType Type { get; set; }
        public SocketAsyncEventArgs Client { get; set; }
        public string Name { get; set; }
    }

    public class UpdatedFiles
    {
        public FileStruct Info { get; set; }
        public byte[] Content { get; set; }
    }
}
