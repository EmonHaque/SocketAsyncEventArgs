﻿using System.Runtime.InteropServices;

namespace Data
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct SockInfo
    {
        //13 bytes
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string Name;
        public bool RecvArg;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HeaderStruct
    {
        //36 bytes
        public bool HasBuy;
        public bool HasSell;
        public bool HasExecuted;
        public bool HasNews;
        public int ItemSize;
        public int BuySize;
        public int SellSize;
        public int ExecutedSize;
        public int NewsSize;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ItemStruct
    {   
        //14 bytes
        public int Id;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)]
        public string Name;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct AllOrderStruct
    {
        //82 bytes
        public int TransactionNo;
        public int SellOrderNo;
        public int BuyOrderNo;
        public Action Action;
        public int ItemCode;
        public OrderType OrderType;
        public int Quantity;
        public float Price;
        public int PartyCode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)]
        public string BrokerName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)]
        public string BrokerBought;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)]
        public string BrokerSold;
        public int PartySold;
        public int PartyBought;
        public int QtyTraded;
        public ExecutionType ExType;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct MessageHeader
    {
        //8 bytes
        public Message Type;
        public int Size;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct News
    {
        //1 kilobyte
        public int ItemCode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 5)]
        public string Time;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1015)]
        public string Feed;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct FileStruct
    {
        //128 bytes
        public int Size;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 124)]
        public string Name;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct UpdateClientStruct
    {
        //16 bytes
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 12)]
        public string Name;
        public ClientType Type;
    }

    public enum Message
    {
        Trade,
        News
    }

    public enum ExecutionType
    {
        None,
        Partial,
        Full
    }

    public enum OrderType
    {
        Buy,
        Sell
    }

    public enum Action
    {
        Add,
        Modify,
        Delete,
        Execute
    }

    public enum ClientType
    {
        General,
        Special
    }
}
