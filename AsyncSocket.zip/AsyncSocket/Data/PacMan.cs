﻿using System;
using System.Runtime.InteropServices;

namespace Data
{
    public class PacMan<Type> where Type : new()
    {
        public static byte[] Pack(Type t)
        {
            int size = Marshal.SizeOf(t);
            byte[] array = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(t, ptr, false);
            Marshal.Copy(ptr, array, 0, size);
            Marshal.FreeHGlobal(ptr);
            return array;
        }

        public static Type Unpack(byte[] ar)
        {
            Type t = new Type();
            int size = Marshal.SizeOf(t);
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.Copy(ar, 0, ptr, size);
            t = (Type)Marshal.PtrToStructure(ptr, t.GetType());
            Marshal.FreeHGlobal(ptr);
            return t;
        }
    }
}
