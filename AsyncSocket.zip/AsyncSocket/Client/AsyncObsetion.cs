﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Threading;
using System.Windows.Data;

namespace Client
{
    public class AsyncObsetion<T> : ObservableCollection<T>
    {
        SynchronizationContext context = SynchronizationContext.Current;
        readonly object _lock = new object();
        public AsyncObsetion() { BindingOperations.EnableCollectionSynchronization(this, _lock); }
        public AsyncObsetion(IEnumerable<T> list) : base(list) { BindingOperations.EnableCollectionSynchronization(this, _lock); }

        void RaiseCollectionChanged(object param) => base.OnCollectionChanged((NotifyCollectionChangedEventArgs)param);
        void RaisePropertyChanged(object param) => base.OnPropertyChanged((PropertyChangedEventArgs)param);

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            if (SynchronizationContext.Current == context) RaiseCollectionChanged(e);
            else context.Send(RaiseCollectionChanged, e);
        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (SynchronizationContext.Current == context) RaisePropertyChanged(e);
            else context.Send(RaisePropertyChanged, e);
        }
    }
}
