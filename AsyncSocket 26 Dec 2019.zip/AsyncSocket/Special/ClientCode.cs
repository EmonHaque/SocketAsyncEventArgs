﻿using Client.UsrCntrls;
using Client.VMs;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace Client
{
    public class ClientCode : INotifyPropertyChanged
    {
        #region TestPropertie
        string numBuyOrder;
        public string NumBuyOrder { get => numBuyOrder; set { numBuyOrder = value; OnPropertyChanged(); } }

        string numSellOrder;
        public string NumSellOrder { get => numSellOrder; set { numSellOrder = value; OnPropertyChanged(); } }

        string numExecutedOrder;
        public string NumExecutedOrder { get => numExecutedOrder; set { numExecutedOrder = value; OnPropertyChanged(); } }

        string timeElapsed;
        public string TimeElapsed { get => timeElapsed; set { timeElapsed = value; OnPropertyChanged(); } }

        DispatcherTimer timer = new DispatcherTimer() { Interval = new TimeSpan(0, 0, 0, 5) };
        int tickCount;
        #endregion

        public static event System.Action OnConnected;
        public static event System.Action OnDisconnected;
        public static object _lock = new object();

        public static string BrokerName { get; set; }
        string status;
        string clientName;
        bool isConnected, hasNewNews, hasReceivedData;
        IPEndPoint endPoint;
        SocketAsyncEventArgs recvArgs;
        public static SocketAsyncEventArgs sendArgs;

        byte[] orderBuffer = new byte[Constants.orderSize];
        byte[] headerBuffer = new byte[Constants.messageHeaderLength];

        UserControl currentContent, home, order, pending, executed, news, makeNews, customerTrade, summary;

        public Command Connect { get; set; }
        public Command Disconnect { get; set; }
        public Command OnClosing { get; set; }

        public Command Go2Order { get; set; }
        public Command Go2Pending { get; set; }
        public Command Go2Executed { get; set; }
        public Command Go2News { get; set; }
        public Command Go2CustomerTrade { get; set; }
        public Command Go2MakeNews { get; set; }
        public Command Update { get; set; }
        public Command Send { get; set; }
        public Command Go2Summary { get; set; }

        public string Status { get => status; set { status = value; OnPropertyChanged(); } }
        public bool IsConnected { get => isConnected; set { isConnected = value; OnPropertyChanged(); } }
        public bool HasNewNews { get => hasNewNews; set { hasNewNews = value; OnPropertyChanged(); } }
        public string ClientName { get => clientName; set { clientName = value; BrokerName = value; OnPropertyChanged(); } }
        public UserControl CurrentContent { get => currentContent; set { currentContent = value; OnPropertyChanged(); } }
        public event PropertyChangedEventHandler PropertyChanged;

        public static AsyncObsetion<Item> Items { get; set; }
        public static AsyncObsetion<AllOrder> BuyOrders { get; set; }
        public static AsyncObsetion<AllOrder> SellOrders { get; set; }
        public static AsyncObsetion<AllOrder> PendingOrders { get; set; }
        public static AsyncObsetion<Issue> Issued { get; set; }

        public static AsyncObsetion<AllOrder> ExecutedOrders { get; set; }
        public static AsyncObsetion<DisplayExecuted> MyExecutedOrders { get; set; }
        public static AsyncObsetion<DisplayNews> NewsCollection { get; set; }
        Queue<DisplayNews> NewsQueue { get; set; }

        public ClientCode()
        {
            InitializeLists();
            InitializeViews();
            InitializeICommands();
            endPoint = new IPEndPoint(IPAddress.Parse(Constants.host), Constants.tradePort);

            timer.Tick += (o, e) =>
            {
                NumBuyOrder = BuyOrders.Count.ToString("N0");
                NumSellOrder = SellOrders.Count.ToString("N0");
                NumExecutedOrder = ExecutedOrders.Count.ToString("N0");
                tickCount++;
                TimeElapsed = (tickCount * 5).ToString("N0");
            };
            timer.Start();
        }

        void InitializeLists()
        {
            Items = new AsyncObsetion<Item>();
            BuyOrders = new AsyncObsetion<AllOrder>();
            SellOrders = new AsyncObsetion<AllOrder>();
            PendingOrders = new AsyncObsetion<AllOrder>();
            Issued = new AsyncObsetion<Issue>();

            ExecutedOrders = new AsyncObsetion<AllOrder>();
            MyExecutedOrders = new AsyncObsetion<DisplayExecuted>();
            NewsCollection = new AsyncObsetion<DisplayNews>();
            NewsQueue = new Queue<DisplayNews>();
            OrderVM.CurrentExecuted = new AsyncObsetion<PVSeries>();
            SecuritiesVM.Series = new AsyncObsetion<PieSeries>();
        }

        void InitializeViews()
        {
            home = new Home();
            order = new Order();
            pending = new Pending();
            executed = new Executed();
            news = new UsrCntrls.News();
            customerTrade = new CustomerTrade();
            makeNews = new MakeNews();
            summary = new Summary();
            CurrentContent = home;
        }

        void InitializeICommands()
        {
            Connect = new Command(Connect2Server, (o) => !IsConnected && !String.IsNullOrEmpty(ClientName));
            Disconnect = new Command(Disconnect4mServer, (o) => IsConnected && hasReceivedData);
            OnClosing = new Command(Disconnect4mServer, (o) => true);

            Go2Order = new Command(SubmitOrder, (o) => IsConnected && hasReceivedData && CurrentContent != order);
            Go2Executed = new Command(SeeExecuted, (o) => IsConnected && hasReceivedData && CurrentContent != executed);
            Go2Pending = new Command(SeePending, (o) => IsConnected && hasReceivedData && CurrentContent != pending);
            Go2News = new Command(SeeNews, (o) => IsConnected && hasReceivedData && NewsQueue.Count > 0);
            Go2CustomerTrade = new Command(SeeCustomerTrade, (o) => CurrentContent != customerTrade && hasReceivedData && MyExecutedOrders.Count > 0);
            Go2MakeNews = new Command(SeeMakeNews, (o) => IsConnected && hasReceivedData && CurrentContent != makeNews);
            Go2Summary = new Command(SeeSummary, (o) => isConnected && hasReceivedData && CurrentContent != summary);
            Update = new Command(UpdateApp, (o) => false);
        }

        void UpdateApp(object obj)
        {
            var writingPath = AppDomain.CurrentDomain.BaseDirectory;
            //var writingPath = @"C:\Users\Emon\source\repos\AsyncSocket\Updater\bin\Debug\netcoreapp3.0\win-x64\";
            var type = "Special";
            var args = BrokerName + "," + type + "," + writingPath;
            Process.Start(writingPath + "Updater.exe", args);
            Disconnect4mServer(null);
            Application.Current.Shutdown();
        }

        void SeeCustomerTrade(object obj)
        {
            CurrentContent = customerTrade;
            CustomerTradeVM.CustomersCode = MyExecutedOrders.Select(x => x.PartyCode).Distinct().OrderBy(x => x);
            CustomerTradeVM.CustomerCode = CustomerTradeVM.CustomersCode.First();
        }

        void SeeNews(object obj)
        {
            CurrentContent = news;
            var count = NewsQueue.Count;
            for (int i = 0; i < count; i++) NewsCollection.Insert(0, NewsQueue.Dequeue());
            HasNewNews = false;
        }

        void SeeMakeNews(object obj) => CurrentContent = makeNews;
        void SubmitOrder(object obj) => CurrentContent = order;
        void SeeExecuted(object obj) => CurrentContent = executed;
        void SeePending(object obj) => CurrentContent = pending;
        void SeeSummary(object obj) => CurrentContent = summary;

        void Connect2Server(object obj)
        {
            Status = "Connecting ...";
            recvArgs = new SocketAsyncEventArgs();
            sendArgs = new SocketAsyncEventArgs();

            recvArgs.AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            sendArgs.AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            recvArgs.RemoteEndPoint = sendArgs.RemoteEndPoint = endPoint;

            recvArgs.Completed += ReceiverConnected;
            sendArgs.Completed += SenderConnected;

            if (!recvArgs.AcceptSocket.ConnectAsync(recvArgs)) ReceiverConnected(null, recvArgs);
            if (!sendArgs.AcceptSocket.ConnectAsync(sendArgs)) SenderConnected(null, sendArgs);
        }

        void ReceiverConnected(object sender, SocketAsyncEventArgs e)
        {
            e.Completed -= ReceiverConnected;
            if (e.SocketError == SocketError.Success)
            {
                SendInfo(e, true, ReceiverInfoSent);
                App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
            }
            else Disconnect4mServer("Server Unreachable");
        }

        void SenderConnected(object sender, SocketAsyncEventArgs e)
        {
            e.Completed -= SenderConnected;
            if (e.SocketError == SocketError.Success)
            {
                SendInfo(e, false, SenderInfoSent);
                App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
            }
            else Disconnect4mServer("Server Unreachable");
        }

        void ReceiverInfoSent(object sender, SocketAsyncEventArgs e)
        {
            e.Completed -= ReceiverInfoSent;
            if (e.SocketError == SocketError.Success)
            {
                SetBuffer(e, Constants.headerSize);
                e.Completed += ReceiveMarketData;
                if (!e.AcceptSocket.ReceiveAsync(e)) ReceiveMarketData(null, e);
            }
            else Disconnect4mServer("Server Unreachable");
        }

        void ReceiveMarketData(object sender, SocketAsyncEventArgs e)
        {
            e.Completed -= ReceiveMarketData;
            if (e.SocketError == SocketError.Success)
            {
                var header = PacMan<HeaderStruct>.Unpack(e.Buffer);
                SetBuffer(e, header.ItemSize + header.BuySize + header.SellSize + header.ExecutedSize + header.NewsSize + header.IssueSize);
                e.AcceptSocket.Receive(e.Buffer);

                var itemArray = e.Buffer.Take(header.ItemSize);
                var buyArray = e.Buffer.Skip(header.ItemSize);
                var sellArray = e.Buffer.Skip(header.ItemSize + header.BuySize);
                var execArray = e.Buffer.Skip(header.ItemSize + header.BuySize + header.SellSize);
                var newsArray = e.Buffer.Skip(header.ItemSize + header.BuySize + header.SellSize + header.ExecutedSize).Take(header.NewsSize);
                var issueArray = e.Buffer.Skip(header.ItemSize + header.BuySize + header.SellSize + header.ExecutedSize + header.NewsSize).Take(header.IssueSize);

                var tasks = new List<Task>();
                tasks.Add(Task.Run(() =>
                {
                    for (int i = 0; i < header.ItemSize; i += Constants.itemSize)
                    {
                        var item = PacMan<ItemStruct>.Unpack(itemArray.Skip(i).Take(Constants.itemSize).ToArray());
                        Items.Add(new Item()
                        {
                            Id = item.Id,
                            Name = item.Name,
                            Cap = item.Cap,
                            Floor = item.Floor,
                            Mid = item.Floor + ((item.Cap - item.Floor) / 2),
                            Securities = item.Securities,
                            Owners = item.Owners,
                            Govt = item.Govt,
                            Institutions = item.Institutions,
                            Foreign = item.Foreign,
                            Public = item.Public,
                            PerSecurity = PacMan<PerSecurityFinancialsStruct>.ArrayToList<PerSecurityFinancials>(item.PerSecurity),
                            Dividends = PacMan<DividendStruct>.ArrayToList<Dividend>(item.Dividends),
                            InitialSecurity = item.InitialSecurity
                        });
                    }
                }).ContinueWith(t => {
                    if (header.HasExecuted) GetExOrders(header.ExecutedSize, execArray);
                    if (header.HasNews) AddNews(newsArray.ToArray());
                }));

                tasks.Add(Task.Run(() => { if (header.HasBuy) GetOrders(header.BuySize, buyArray); }));
                tasks.Add(Task.Run(() => { if (header.HasSell) GetOrders(header.SellSize, sellArray); }));
                tasks.Add(Task.Run(() => AddIssue(issueArray.ToArray())));
                Task.WaitAll(tasks.ToArray());

                hasReceivedData = true;              
                App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
                OnConnected?.Invoke();

                var firstItemsId = Items.First().Id;
                OrderVM.ItemCode = firstItemsId;
                MarketNewsVM.ItemCode = firstItemsId;
                SummaryVM.ItemCode = firstItemsId;

                e.Completed += Receive;
                e.SetBuffer(headerBuffer, 0, headerBuffer.Length);
                if (!e.AcceptSocket.ReceiveAsync(e)) Receive(null, e);
            }
            else
            {

            }
        }

        void AddIssue(byte[] array)
        {
            for (int i = 0; i < array.Length; i += Constants.issueSize)
            {
                var issue = PacMan<IssueStruct>.Unpack(array.Skip(i).Take(Constants.issueSize).ToArray());
                Issued.Add(new Issue()
                {
                    Id = issue.Id,
                    Percent = issue.Percent,
                    Type = issue.Type,
                    Year = issue.Year
                });
            }
        }

        void GetOrders(int size, IEnumerable<byte> array)
        {
            for (int i = 0; i < size; i += Constants.orderSize)
            {
                var order = PacMan<AllOrderStruct>.Unpack(array.Skip(i).Take(Constants.orderSize).ToArray());
                AddNewOrder(order);
            }
        }

        void GetExOrders(int size, IEnumerable<byte> array)
        {
            var executedOrders = new List<AllOrder>();
            var myExecutedOrders = new List<DisplayExecuted>();

            for (int i = 0; i < size; i += Constants.orderSize)
            {
                var order = PacMan<AllOrderStruct>.Unpack(array.Skip(i).Take(Constants.orderSize).ToArray());
                AddExecutedOrderOnConnected(order, executedOrders, myExecutedOrders);
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                CheckSizeAndAdd(executedOrders, ExecutedOrders);
                CheckSizeAndAdd(myExecutedOrders, MyExecutedOrders);
            });
        }

        void CheckSizeAndAdd<T>(List<T> normalList, AsyncObsetion<T> observableList)
        {
            var count = normalList.Count;
            if (count > 30)
            {
                observableList.InsertRange(normalList.Take(count - 30).Reverse());
                var remaining = normalList.Skip(count - 30).ToList();
                for (int i = 0; i < remaining.Count; i++)
                {
                    if (remaining[i] is AllOrder)
                    {
                        AllOrder lastTrade;
                        var tran = remaining[i] as AllOrder;
                        if (i == 0) lastTrade = observableList.Select(x => x as AllOrder).LastOrDefault(x => x.ItemCode == tran.ItemCode);
                        else lastTrade = observableList.Select(x => x as AllOrder).FirstOrDefault(x => x.ItemCode == tran.ItemCode);
                        if (lastTrade != null)
                        {
                            if (lastTrade.Price < tran.Price) tran.UpDownOrNone = 1;
                            if (lastTrade.Price > tran.Price) tran.UpDownOrNone = -1;
                            if (lastTrade.Price == tran.Price) tran.UpDownOrNone = 0;
                        }
                    }
                    observableList.Insert(0, remaining[i]);
                }
            }
            else
            {
                for (int i = 0; i < count; i++)
                {
                    if (normalList[i] is AllOrder)
                    {
                        AllOrder lastTrade;
                        var tran = normalList[i] as AllOrder;
                        if (i == 0) lastTrade = null;
                        else lastTrade = observableList.Select(x => x as AllOrder).FirstOrDefault(x => x.ItemCode == tran.ItemCode);
                        if (lastTrade != null)
                        {
                            if (lastTrade.Price < tran.Price) tran.UpDownOrNone = 1;
                            if (lastTrade.Price > tran.Price) tran.UpDownOrNone = -1;
                            if (lastTrade.Price == tran.Price) tran.UpDownOrNone = 0;
                        }
                    }
                    observableList.Insert(0, normalList[i]);
                }
            }
        }

        void SenderInfoSent(object sender, SocketAsyncEventArgs e)
        {
            e.Completed -= SenderInfoSent;
            if (e.SocketError == SocketError.Success)
            {
                e.SetBuffer(null);
                e.Completed += Sent;
            }
            else Disconnect4mServer("Server Unreachable");
        }

        void Receive(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                var data = PacMan<MessageHeader>.Unpack(e.Buffer);
                if(data.Type == Message.Trade)
                {
                    e.SetBuffer(orderBuffer, 0, orderBuffer.Length);
                    e.AcceptSocket.Receive(e.Buffer);
                    var order = PacMan<AllOrderStruct>.Unpack(e.Buffer);

                    switch (order.Action)
                    {
                        case Data.Action.Add: AddNewOrder(order); break;
                        case Data.Action.Delete: RemoveOrder(order); break;
                        case Data.Action.Modify: ModifyOrder(order); break;
                        case Data.Action.Execute: UpdateOrderOnExecution(order); break;
                    }
                }
                else
                {
                    SetBuffer(e, data.Size);
                    e.AcceptSocket.Receive(e.Buffer);
                    var array = e.Buffer.ToArray();
                    Task.Run(() => AddNews(array));
                }

                e.SetBuffer(headerBuffer, 0, headerBuffer.Length);
                if (!e.AcceptSocket.ReceiveAsync(e)) Receive(null, e);
            }
            else Disconnect4mServer(null);
        }

        void AddNews(byte[] array)
        {
            for (int i = 0; i < array.Length; i += Constants.newsSize)
            {
                var n = PacMan<Data.News>.Unpack(array.Skip(i).Take(Constants.newsSize).ToArray());
                NewsQueue.Enqueue(new DisplayNews()
                {
                    Time = n.Time,
                    ItemCode = n.ItemCode,
                    ItemName = Items.First(x => x.Id == n.ItemCode).Name,
                    Feed = n.Feed
                });
            }
            HasNewNews = true;
            App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
        }

        void UpdateOrderOnExecution(AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var list = buyOrder ? BuyOrders : SellOrders;
            var o = buyOrder ? list.Where(x => x.BuyOrderNo == order.BuyOrderNo).First() : list.Where(x => x.SellOrderNo == order.SellOrderNo).First();
            o.ExType = order.ExType;

            if (order.ExType == ExecutionType.Full) list.Remove(o);
            else
            {
                var index = list.IndexOf(o);
                o.Quantity -= order.QtyTraded;
                list[index] = o;
            }
            AddExecutedOrder(order);
            if (order.BrokerBought == BrokerName || order.BrokerSold == BrokerName) UpDatePendingOrders(o);
            App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
        }

        void AddExecutedOrderOnConnected(AllOrderStruct order, List<AllOrder> executedOrders, List<DisplayExecuted> myExecutedOrders)
        {
            var tran = Transaction(order);
            executedOrders.Add(tran);

            if (order.BrokerBought == BrokerName || order.BrokerSold == BrokerName)
            {
                var executed = new DisplayExecuted();

                executed.TransactionNo = tran.TransactionNo;
                executed.ItemCode = tran.ItemCode;
                executed.ItemName = tran.ItemName;
                executed.BuyOrderNo = tran.BuyOrderNo;
                executed.SellOrderNo = tran.SellOrderNo;
                executed.Price = tran.Price;
                executed.QtyTraded = tran.QtyTraded;

                if (order.BrokerBought == BrokerName && order.BrokerSold == BrokerName)
                {
                    var exec2 = executed.Clone() as DisplayExecuted;

                    executed.PartyCode = tran.PartyBought;
                    executed.ToFromBroker = BrokerName;
                    executed.ToFromParty = tran.PartySold;
                    executed.Type = "Buy";

                    exec2.PartyCode = tran.PartySold;
                    exec2.ToFromBroker = BrokerName;
                    exec2.ToFromParty = tran.PartyBought;
                    exec2.Type = "Sell";
                    myExecutedOrders.Add(exec2);
                }
                else
                {
                    var buyOrder = order.BrokerBought == BrokerName;

                    executed.PartyCode = buyOrder ? tran.PartyBought : tran.PartySold;
                    executed.ToFromBroker = buyOrder ? tran.BrokerSold : tran.BrokerBought;
                    executed.ToFromParty = buyOrder ? tran.PartySold : tran.PartyBought;
                    executed.Type = buyOrder ? "Buy" : "Sell";
                }
                myExecutedOrders.Add(executed);
            }
        }

        void AddExecutedOrder(AllOrderStruct order)
        {
            var tran = Transaction(order);
            var lastTrade = ExecutedOrders.FirstOrDefault(x => x.ItemCode == tran.ItemCode);
            if (lastTrade != null)
            {
                if (lastTrade.Price < tran.Price) tran.UpDownOrNone = 1;
                if (lastTrade.Price > tran.Price) tran.UpDownOrNone = -1;
                if (lastTrade.Price == tran.Price) tran.UpDownOrNone = 0;
            }
            ExecutedOrders.Insert(0, tran);

            if (order.BrokerBought == BrokerName || order.BrokerSold == BrokerName)
            {
                var executed = new DisplayExecuted();

                executed.TransactionNo = tran.TransactionNo;
                executed.ItemCode = tran.ItemCode;
                executed.ItemName = tran.ItemName;
                executed.BuyOrderNo = tran.BuyOrderNo;
                executed.SellOrderNo = tran.SellOrderNo;
                executed.Price = tran.Price;
                executed.QtyTraded = tran.QtyTraded;

                if (order.BrokerBought == BrokerName && order.BrokerSold == BrokerName)
                {
                    var exec2 = executed.Clone() as DisplayExecuted;

                    executed.PartyCode = tran.PartyBought;
                    executed.ToFromBroker = BrokerName;
                    executed.ToFromParty = tran.PartySold;
                    executed.Type = "Buy";

                    exec2.PartyCode = tran.PartySold;
                    exec2.ToFromBroker = BrokerName;
                    exec2.ToFromParty = tran.PartyBought;
                    exec2.Type = "Sell";
                    MyExecutedOrders.Insert(0, exec2);
                }
                else
                {
                    var buyOrder = order.BrokerBought == BrokerName;

                    executed.PartyCode = buyOrder ? tran.PartyBought : tran.PartySold;
                    executed.ToFromBroker = buyOrder ? tran.BrokerSold : tran.BrokerBought;
                    executed.ToFromParty = buyOrder ? tran.PartySold : tran.PartyBought;
                    executed.Type = buyOrder ? "Buy" : "Sell";
                }
                MyExecutedOrders.Insert(0, executed);
            }
        }

        void UpDatePendingOrders(AllOrder o)
        {
            var p = PendingOrders.FirstOrDefault(x => x == o);
            if (p != null)
            {
                switch (o.ExType)
                {
                    case ExecutionType.Full: PendingOrders.Remove(p); break;
                    case ExecutionType.Partial:
                        var index = PendingOrders.IndexOf(p);
                        p.Quantity = o.Quantity;
                        PendingOrders[index] = p;
                        break;
                }
            }
        }

        AllOrder Transaction(AllOrderStruct order)
        {
            return new AllOrder()
            {
                Action = order.Action,
                BrokerName = order.BrokerName,
                ItemCode = order.ItemCode,
                ItemName = Items.First(x=>x.Id == order.ItemCode).Name,
                OrderType = order.OrderType,
                PartyCode = order.PartyCode,
                Price = order.Price,
                QtyTraded = order.QtyTraded,
                Quantity = order.Quantity,
                TransactionNo = order.TransactionNo,
                BrokerBought = order.BrokerBought,
                BrokerSold = order.BrokerSold,
                PartyBought = order.PartyBought,
                PartySold = order.PartySold,
                BuyOrderNo = order.BuyOrderNo,
                SellOrderNo = order.SellOrderNo,
                ExType = order.ExType,
                ExecutionTime = order.ExecutionTime
            };
        }

        void AddNewOrder(AllOrderStruct order)
        {
            var orderList = order.OrderType == OrderType.Buy ? BuyOrders : SellOrders;
            var o = new AllOrder();
            o.Action = order.Action;
            o.OrderType = order.OrderType;
            o.ItemCode = order.ItemCode;
            o.BrokerName = order.BrokerName;
            o.PartyCode = order.PartyCode;
            o.Price = order.Price;
            o.Quantity = order.Quantity;
            o.BuyOrderNo = order.BuyOrderNo;
            o.SellOrderNo = order.SellOrderNo;
            orderList.Add(o);
            if (o.BrokerName == BrokerName) PendingOrders.Add(o);
        }

        void RemoveOrder(AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var list = buyOrder ? BuyOrders : SellOrders;
            var o = buyOrder ? list.Where(x => x.BuyOrderNo == order.BuyOrderNo).First()
                            : list.Where(x => x.SellOrderNo == order.SellOrderNo).First();
            list.Remove(o);

            if (order.BrokerName == BrokerName) PendingOrders.Remove(o);

        }

        void ModifyOrder(AllOrderStruct order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var list = buyOrder ? BuyOrders : SellOrders;
            var o = buyOrder ? list.Where(x => x.BuyOrderNo == order.BuyOrderNo).First()
                            : list.Where(x => x.SellOrderNo == order.SellOrderNo).First();
            var index = list.IndexOf(o);
            o.Price = order.Price;
            o.Quantity = order.Quantity;
            list[index] = o;

            if (order.BrokerName == BrokerName)
            {
                var p = buyOrder ? PendingOrders.Where(x => x.BuyOrderNo == order.BuyOrderNo).First()
                                 : PendingOrders.Where(x => x.SellOrderNo == order.SellOrderNo).First();
                index = PendingOrders.IndexOf(p);
                p.Price = order.Price;
                p.Quantity = order.Quantity;
                PendingOrders[index] = p;
            }
        }

        void Sent(object s, SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {

            }
            else Disconnect4mServer(null);
        }

        void SendInfo(SocketAsyncEventArgs e, bool isRecvArg, EventHandler<SocketAsyncEventArgs> handler)
        {
            e.SetBuffer(PacMan<SockInfo>.Pack(new SockInfo() { Name = ClientName, RecvArg = isRecvArg }));
            e.Completed += handler;
            if (!e.AcceptSocket.SendAsync(e)) handler(null, e);
            IsConnected = true;
            Status = "Connected";
        }

        void Disconnect4mServer(object obj)
        {
            lock (_lock)
            {
                if (IsConnected)
                {
                    recvArgs.AcceptSocket.Close();
                    recvArgs.AcceptSocket.Dispose();
                    recvArgs.Dispose();

                    sendArgs.AcceptSocket.Close();
                    sendArgs.AcceptSocket.Dispose();
                    sendArgs.Dispose();

                    OnDisconnected?.Invoke();
                    ClearLists();
                    IsConnected = HasNewNews = hasReceivedData = false;
                    Status = obj == null ? "Connect to Server" : obj as string;
                    App.Current.Dispatcher.Invoke(CommandManager.InvalidateRequerySuggested);
                    CurrentContent = home;
                }
            }
        }

        void ClearLists()
        {
            if (Items.Count > 0) Items.Clear();
            if (BuyOrders.Count > 0) BuyOrders.Clear();
            if (SellOrders.Count > 0) SellOrders.Clear();
            if (PendingOrders.Count > 0) PendingOrders.Clear();
            if (ExecutedOrders.Count > 0) ExecutedOrders.Clear();
            if (MyExecutedOrders.Count > 0) MyExecutedOrders.Clear();
            if (NewsCollection.Count > 0) NewsCollection.Clear();
            if (NewsQueue.Count > 0) NewsQueue.Clear();
            if (Issued.Count > 0) Issued.Clear();
        }

        void SetBuffer(SocketAsyncEventArgs e, int length) => e.SetBuffer(new byte[length], 0, length);

        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class Command : ICommand
    {
        Action<object> Do;
        Func<object, bool> CanDo;

        public Command(Action<object> Do, Func<object, bool> CanDo)
        {
            this.CanDo = CanDo;
            this.Do = Do;
            CommandManager.RequerySuggested += (o, e) => Changed();
        }

        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter) => CanDo(parameter);
        public void Execute(object parameter) => Do(parameter);
        public void Changed() => CanExecuteChanged?.Invoke(null, EventArgs.Empty);
    }

    public class TradeColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var x = (sbyte)value;
            SolidColorBrush brush = null;
            switch (x)
            {
                case 1: brush = new SolidColorBrush(Colors.Green); break;
                case -1: brush = new SolidColorBrush(Colors.Red); break;
                case 0: brush = new SolidColorBrush(Colors.Blue); break;
            }
            return brush;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
