﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using Data;

namespace Updater
{
    public class UpdaterCode : INotifyPropertyChanged
    {
        SocketAsyncEventArgs e;
        IPEndPoint endPoint;
        int payload, totalReceived;
        double percentReceived;
        string clientName, writingPath, type, updateText;
        List<SentFiles> files;
        ClientType clientType;
        byte[] buff = new byte[Constants.fileInfoBuffLength];

        public string UpdateText { get => updateText; set { updateText = value; OnPropertyChanged(); } }
        public double PercentReceived { get => percentReceived; set { percentReceived = value; OnPropertyChanged(); } }

        public Command Move { get; set; }

        public UpdaterCode()
        {
            Move = new Command(MoveWindow, (o) => true);
            var args = Environment.GetCommandLineArgs().Skip(1).First().Split(",");
            clientName = args[0];
            type = args[1];
            writingPath = args[2];

            e = new SocketAsyncEventArgs();
            endPoint = new IPEndPoint(IPAddress.Parse(Constants.host), Constants.filePort);
            files = new List<SentFiles>();

            e.AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            e.RemoteEndPoint = endPoint;
            e.Completed += Connected;
            if (!e.AcceptSocket.ConnectAsync(e)) Connected(null, e);
        }

        void MoveWindow(object obj) => ((Window)obj).DragMove();

        void Connected(object sender, SocketAsyncEventArgs e)
        {
           if(e.SocketError == SocketError.Success)
            {
                clientType = type == "General" ? ClientType.General : ClientType.Special;
                e.Completed -= Connected;
                var info = new UpdateClientStruct()
                {
                    Name = clientName,
                    Type = clientType
                };

                e.AcceptSocket.Send(PacMan<UpdateClientStruct>.Pack(info));
                e.Completed += Received;
                e.SetBuffer(buff, 0, Constants.fileInfoBuffLength);
                if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
            }
           else
            {
                UpdateText = "Server Unreachable!";
                Thread.Sleep(1000);
                Close();
            }
        }

        void Received(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                var info = PacMan<FileStruct>.Unpack(e.Buffer);
                if(info.Name == "TotalSize")
                {
                    payload = info.Size;
                    if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
                }
                else
                {
                    if (info.Name != "EOF")
                    {
                        e.SetBuffer(new byte[info.Size], 0, info.Size);
                        e.AcceptSocket.Receive(e.Buffer);
                        var file = new SentFiles() { Name = info.Name, Bytes = e.Buffer.ToArray() };
                        files.Add(file);
                        Thread.Sleep(50);
                        totalReceived += info.Size;
                        PercentReceived += ((double)info.Size / payload) * 100;
                        UpdateText = $"{totalReceived} of {payload} bytes received";
                        e.SetBuffer(buff, 0, Constants.fileInfoBuffLength);
                        if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
                    }
                    else WriteFiles();
                }
            }
            else if(e.SocketError == SocketError.ConnectionReset)
            {
                UpdateText = "Server Unreachable!";
                Thread.Sleep(500);
                if(files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        Thread.Sleep(50);
                        PercentReceived -= ((double)file.Bytes.Count() / payload) * 100;
                    }
                }
                Close();
            }
        }

        void Close()
        {
            e.AcceptSocket.Close();
            e.AcceptSocket.Dispose();
            e.Dispose();

            UpdateText = "Reloading Application ...";
            Thread.Sleep(1000);

            string appName = clientType == ClientType.Special ? "Special.exe" : "Client.exe";
            Process.Start(writingPath + appName);
            Application.Current.Shutdown();
        }

        void WriteFiles()
        {
            foreach (var file in files)
            {
                UpdateText = $"Updating {file.Name}";
                Thread.Sleep(50);
                using (var stream = new FileStream(writingPath + file.Name, FileMode.Create, FileAccess.Write))
                    stream.Write(file.Bytes, 0, file.Bytes.Length);
            }
            Close();
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class SentFiles
    {
        public string Name { get; set; }
        public byte[] Bytes { get; set; }
    }

    public class Command : ICommand
    {
        Action<object> Do;
        Func<object, bool> CanDo;

        public Command(Action<object> Do, Func<object, bool> CanDo)
        {
            this.CanDo = CanDo;
            this.Do = Do;
            CommandManager.RequerySuggested += (o, e) => Changed();
        }

        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter) => CanDo(parameter);
        public void Execute(object parameter) => Do(parameter);
        public void Changed() => CanExecuteChanged?.Invoke(null, EventArgs.Empty);
    }
}
