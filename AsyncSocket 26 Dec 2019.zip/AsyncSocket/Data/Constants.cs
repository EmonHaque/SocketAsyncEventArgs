﻿namespace Data
{
    public class Constants
    {
        public static int tradePort = 65535;
        public static int filePort = 65534;
        public static int infoBuffLength = 13;
        public static int fileInfoBuffLength = 128;
        public static int itemSize = 458;
        public static int orderSize = 88;
        public static int newsSize = 1024;
        public static int messageHeaderLength = 8;
        public static int headerSize = 40;
        public static int issueSize = 16;

        public static string host = "127.0.0.1";
    }
}
