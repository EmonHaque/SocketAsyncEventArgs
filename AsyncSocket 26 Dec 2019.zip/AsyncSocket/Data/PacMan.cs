﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace Data
{
    public class PacMan<Type> where Type : new()
    {
        public static byte[] Pack(Type t)
        {
            int size = Marshal.SizeOf(t);
            byte[] array = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(t, ptr, false);
            Marshal.Copy(ptr, array, 0, size);
            Marshal.FreeHGlobal(ptr);
            return array;
        }

        public static Type Unpack(byte[] ar)
        {
            Type t = new Type();
            int size = Marshal.SizeOf(t);
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.Copy(ar, 0, ptr, size);
            t = (Type)Marshal.PtrToStructure(ptr, t.GetType());
            Marshal.FreeHGlobal(ptr);
            return t;
        }

        public static Type[] ListToArray<T>(List<T> list)
        {
            var fields = typeof(Type).GetFields();
            var properties = typeof(T).GetProperties();
            var array = new Type[list.Count];

            for (int i = 0; i < array.Length; i++)
            {
                foreach (var field in fields)
                {
                    var value = properties.First(x => x.Name == field.Name).GetValue(list[i]);
                    field.SetValueDirect(__makeref(array[i]), value);
                }
            }
            return array;
        }

        public static List<T> ArrayToList<T>(Type[] array) where T : new()
        {
            var fields = typeof(Type).GetFields();
            var properties = typeof(T).GetProperties();
            var list = new List<T>(array.Length);

            for (int i = 0; i < array.Length; i++)
            {
                var obj = new T();
                foreach (var property in properties)
                {
                    var value = fields.First(x => x.Name == property.Name).GetValue(array[i]);
                    property.SetValue(obj, value);
                }
                list.Add(obj);
            }
            return list;
        }
    }
}
