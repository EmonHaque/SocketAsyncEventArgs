﻿using Data;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Client.VMs
{
    public class SummaryVM : INotifyPropertyChanged
    {

        static int itemCode;
        static string broker;
        static List<SumBy> byBroker, byParty;
        static List<AllOrder> currentList;
        static SumBy selected;

        public static string Broker { get => broker; set { broker = value; OnStaticPropertyChanged(); } }
        public static int ItemCode { 
            get => itemCode; 
            set { 
                itemCode = value;
                selected = null;
                ByParty = null;
                Broker = string.Empty;
                UpdateSummary();
                OnStaticPropertyChanged(); 
            } 
        }

        public static List<SumBy> ByBroker { get => byBroker; set { byBroker = value; OnStaticPropertyChanged(); } }
        public static List<SumBy> ByParty { get => byParty; set { byParty = value; OnStaticPropertyChanged(); } }
        public Command UpdateInfo { get; set; }
        public SummaryVM()
        {
            ClientCode.OnConnected += Subscribe;
            ClientCode.OnDisconnected += Unsubscribe;
            
            UpdateInfo = new Command(UpdateBrokerInfo, (o) => currentList.Count > 0);
        }

        void Subscribe()
        {
            ClientCode.ExecutedOrders.CollectionChanged += Update;
        }

        void Unsubscribe()
        {
            ClientCode.ExecutedOrders.CollectionChanged -= Update;
        }

        static void Update(object sender, NotifyCollectionChangedEventArgs e)
        {
            if(e.Action == NotifyCollectionChangedAction.Add)
            {
                var order = e.NewItems[0] as AllOrder;
                if (order.ItemCode == ItemCode) UpdateSummary();
            }
        }

        static void UpdateSummary()
        {
            currentList = ClientCode.ExecutedOrders.Where(x => x.ItemCode == ItemCode).ToList();
            var buys = currentList.GroupBy(x => x.BrokerBought).Select(x => new
            {
                Name = x.Key,
                Buys = x.Sum(x => x.QtyTraded)
            });

            var sells = currentList.GroupBy(x => x.BrokerSold).Select(x => new
            {
                Name = x.Key,
                Sells = x.Sum(x => x.QtyTraded)
            });

            var brokers = buys.Select(x => x.Name).Concat(sells.Select(x => x.Name)).Distinct().OrderBy(x => x);
            var summary = new List<SumBy>(brokers.Count());
            foreach (var broker in brokers)
            {
                var sum = new SumBy();
                sum.Name = broker;
                var bought = buys.FirstOrDefault(x => x.Name == broker);
                var sold = sells.FirstOrDefault(x => x.Name == broker);
                if (bought != null) sum.Buys = bought.Buys;
                if (sold != null) sum.Sells = sold.Sells;
                summary.Add(sum);
            }
            ByBroker = summary;
            if (selected != null) UpdateBrokerInfo(selected);
        }

        static void UpdateBrokerInfo(object obj)
        {
            if(obj != null)
            {
                selected = obj as SumBy;
                Broker = selected.Name;

                var buys = currentList.Where(x => x.BrokerBought == Broker).GroupBy(x => x.PartyBought).Select(x => new
                {
                    Name = x.Key,
                    Buys = x.Sum(x => x.QtyTraded)
                });

                var sells = currentList.Where(x => x.BrokerSold == Broker).GroupBy(x => x.PartySold).Select(x => new
                {
                    Name = x.Key,
                    Sells = x.Sum(x => x.QtyTraded)
                });

                var parties = buys.Select(x => x.Name).Concat(sells.Select(x => x.Name)).Distinct().OrderBy(x => x);
                var summary = new List<SumBy>(parties.Count());
                foreach (var party in parties)
                {
                    var sum = new SumBy();
                    sum.Name = party.ToString();
                    var bought = buys.FirstOrDefault(x => x.Name == party);
                    var sold = sells.FirstOrDefault(x => x.Name == party);
                    if (bought != null) sum.Buys = bought.Buys;
                    if (sold != null) sum.Sells = sold.Sells;
                    summary.Add(sum);
                }
                ByParty = summary;
            }
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }
}
