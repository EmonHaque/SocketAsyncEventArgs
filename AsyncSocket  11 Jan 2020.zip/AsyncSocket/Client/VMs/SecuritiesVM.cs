﻿using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace Client.VMs
{
    public class SecuritiesVM : INotifyPropertyChanged
    {
        double xCenter, yCenter, radius;
        Dictionary<string, double> values;
        Brush[] brushes = { Brushes.Red, Brushes.Black, Brushes.Blue, Brushes.Gray, Brushes.BurlyWood, Brushes.Green };
        public static AsyncObsetion<PieSeries> Series { get; set; }
        public Command Resized { get; set; }

        Series finSeries;
        public Series FinSeries { get => finSeries; set { finSeries = value; OnPropertyChanged(); } }

        IEnumerable<Issue> issueSeries;
        public IEnumerable<Issue> IssueSeries { get => issueSeries; set { issueSeries = value; OnPropertyChanged(); } }


        public SecuritiesVM()
        {
            Resized = new Command(resized, (o) => true);
            values = new Dictionary<string, double>();
            ClientCode.OnConnected += Subscribe;
            ClientCode.OnDisconnected += Unsubscribe;
            FinSeries = new Series();
        }

        void Subscribe()
        {
            OrderVM.ItemChangedEvent += ResetPie;
            OrderVM.ItemChangedEvent += ResetFinSeries;
        }

        void Unsubscribe()
        {
            OrderVM.ItemChangedEvent -= ResetPie;
            OrderVM.ItemChangedEvent -= ResetFinSeries;
        }

        void ResetFinSeries()
        {
            var s = new Series()
            {
                EPS = OrderVM.CurrentItem.PerSecurity.Select(x => x.EPS).ToList(),
                NAV = OrderVM.CurrentItem.PerSecurity.Select(x => x.NAV).ToList(),
                Cash = OrderVM.CurrentItem.PerSecurity.Select(x => x.Cash).ToList(),
                Debt = OrderVM.CurrentItem.PerSecurity.Select(x => x.Debt).ToList(),
                YearQ = OrderVM.CurrentItem.PerSecurity.Select(x => x.YQ).ToList()
            };
            FinSeries = s;
            IssueSeries = ClientCode.Issued.Where(x => x.Id == OrderVM.CurrentItem.Id);
        }

        void ResetPie()
        {
            Series.Clear();
            values.Clear();
            values.Add("O", OrderVM.CurrentItem.Owners);
            values.Add("G", OrderVM.CurrentItem.Govt);
            values.Add("I", OrderVM.CurrentItem.Institutions);
            values.Add("F", OrderVM.CurrentItem.Foreign);
            values.Add("P", OrderVM.CurrentItem.Public);
            DrawPie();
        }

        void resized(object o)
        {
            var pie = o as Canvas;
            xCenter = pie.ActualWidth / 2;
            yCenter = pie.ActualHeight / 2;
            if (xCenter <= yCenter) radius = 0.9 * xCenter;
            else radius = 0.9 * yCenter;
            Series.Clear();
            DrawPie();
        }

        void DrawPie()
        {
            var sum = values.Values.Sum();
            double startAngle, sweepAngle, endAngle;
            startAngle = sweepAngle = endAngle = 0;

            for (int i = 0; i < values.Values.Count; i++)
            {
                startAngle += sweepAngle;
                sweepAngle = 2 * Math.PI * values.ElementAt(i).Value / sum;
                endAngle = startAngle + sweepAngle;

                //double dx = 5 * Math.Cos(startAngle + sweepAngle / 2);
                //double dy = 5 * Math.Sin(startAngle + sweepAngle / 2);

                //xCenter = pie.ActualWidth / 2 + dx;
                //yCenter = pie.ActualHeight / 2 + dy;

                var line1 = new LineSegment() { Point = new Point(xCenter + radius * Math.Cos(startAngle), yCenter + radius * Math.Sin(startAngle)) };
                var arc = new ArcSegment()
                {
                    Point = new Point(xCenter + radius * Math.Cos(endAngle), yCenter + radius * Math.Sin(endAngle)),
                    SweepDirection = SweepDirection.Clockwise,
                    Size = new Size(radius, radius),
                    IsLargeArc = values.ElementAt(i).Value > 50 ? true : false
                };
                var line2 = new LineSegment() { Point = new Point(xCenter + radius * Math.Cos(endAngle), yCenter + radius * Math.Sin(endAngle)) };

                var figure = new PathFigure() { IsClosed = true, StartPoint = new Point(xCenter, yCenter), Segments = { line1, arc, line2 } };
                var pathGeo = new PathGeometry() { Figures = { figure } };
                var ellipseGeo = new EllipseGeometry(new Point(xCenter, yCenter), radius - 30, radius - 30);

                Series.Add(new PieSeries()
                {
                    //Geo = pathGeo,
                    Geo = new CombinedGeometry(GeometryCombineMode.Exclude, pathGeo, ellipseGeo),
                    Fill = brushes[i],
                    Stroke = Brushes.Black,
                    Thickness = 1,
                    Category = values.ElementAt(i).Key,
                    Percent = values.ElementAt(i).Value.ToString("N2") + "%"
                });

            }
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class Series
    {
        public List<float> EPS { get; set; }
        public List<float> NAV { get; set; }
        public List<float> Cash { get; set; }
        public List<float> Debt { get; set; }
        public List<string> YearQ { get; set; }
    }

    public class PieSeries
    {
        public string Category { get; set; }
        public string Percent { get; set; }
        public Geometry Geo { get; set; }
        public Brush Fill { get; set; }
        public Brush Stroke { get; set; }
        public double Thickness { get; set; }
    }

    public class SecuritiesConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var number = (int)value;
            if (number < 1000000) return (number / 1000).ToString("N2") + "k";
            else if (number < 1000000000) return (number / 1000000).ToString("N2") + "m";
            else return (number / 1000000000).ToString("N2") + "b";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
