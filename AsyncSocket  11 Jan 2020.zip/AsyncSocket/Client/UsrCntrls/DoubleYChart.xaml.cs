﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for DoubleYChart.xaml
    /// </summary>
    public partial class DoubleYChart : UserControl
    {
        #region Dependenct Properties
        public static readonly DependencyProperty SeriesAProperty =
            DependencyProperty.Register("SeriesA", typeof(List<float>), typeof(DoubleYChart), new PropertyMetadata(null, setBoundsA));
        public static readonly DependencyProperty SeriesBProperty =
           DependencyProperty.Register("SeriesB", typeof(List<float>), typeof(DoubleYChart), new PropertyMetadata(null, setBoundsB));
        public static readonly DependencyProperty YearQProperty =
            DependencyProperty.Register("YearQ", typeof(List<string>), typeof(DoubleYChart), new PropertyMetadata(null));
        public static readonly DependencyProperty SeriesALabelProperty =
           DependencyProperty.Register("SeriesALabel", typeof(string), typeof(DoubleYChart), new PropertyMetadata(null));
        public static readonly DependencyProperty SeriesBLabelProperty =
           DependencyProperty.Register("SeriesBLabel", typeof(string), typeof(DoubleYChart), new PropertyMetadata(null));
        public static readonly DependencyProperty IsStampVisibleProperty =
           DependencyProperty.Register("IsStampVisible", typeof(bool), typeof(DoubleYChart), new PropertyMetadata(false));

        public List<float> SeriesA
        {
            get { return (List<float>)GetValue(SeriesAProperty); }
            set { SetValue(SeriesAProperty, value); }
        }

        public List<float> SeriesB
        {
            get { return (List<float>)GetValue(SeriesBProperty); }
            set { SetValue(SeriesBProperty, value); }
        }

        public List<string> YearQ
        {
            get { return (List<string>)GetValue(YearQProperty); }
            set { SetValue(YearQProperty, value); }
        }

        public string SeriesALabel
        {
            get { return (string)GetValue(SeriesALabelProperty); }
            set { SetValue(SeriesALabelProperty, value); }
        }

        public string SeriesBLabel
        {
            get { return (string)GetValue(SeriesBLabelProperty); }
            set { SetValue(SeriesBLabelProperty, value); }
        }

        public bool IsStampVisible
        {
            get { return (bool)GetValue(IsStampVisibleProperty); }
            set { SetValue(IsStampVisibleProperty, value); }
        }

        static void setBoundsB(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var instance = d as DoubleYChart;
            instance.maxB = instance.minB = 0;
            foreach (var item in instance.SeriesB)
            {
                if (instance.maxB < item) instance.maxB = item;
                else if (instance.minB > item) instance.minB = item;
            }
            instance.drawGrid();
        }

        static void setBoundsA(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var instance = d as DoubleYChart;
            instance.maxA = instance.minA = 0;
            foreach (var item in instance.SeriesA)
            {
                if (instance.maxA < item) instance.maxA = item;
                else if (instance.minA > item) instance.minA = item;
            }
        }
        #endregion

        int numGridLine = 4;
        double chartWidth, chartHeight, maxA, maxB, minA, minB, thickness;
        PointCollection pointsA, pointsB;
        Brush aBrush, bBrush;

        public DoubleYChart()
        {
            InitializeComponent();
            pointsA = new PointCollection();
            pointsB = new PointCollection();
            aBrush = Brushes.Green;
            bBrush = Brushes.Red;
            chartArea.SizeChanged += resized;
            thickness = 1;
        }

        void resized(object sender, SizeChangedEventArgs e)
        {
            chartWidth = chartArea.ActualWidth;
            chartHeight = chartArea.ActualHeight;
            drawGrid();
        }

        void drawGrid()
        {
            chartArea.Children.Clear();
            var yShift = chartHeight / numGridLine;
            double yPosition = chartHeight;
            double labelA = minA;
            double labelB = minB;
            double labelAIncrement = (maxA - minA) / numGridLine;
            double labelBIncrement = (maxB - minB) / numGridLine;

            for (int i = 0; i <= numGridLine; i++)
            {
                var line = new Line() { X1 = 0, X2 = chartWidth, Y1 = yPosition, Y2 = yPosition, Stroke = Brushes.Black, StrokeThickness = 0.25 };
                var tickA = new TextBlock() { Text = labelA.ToString("N2"), Foreground = aBrush };
                var tickB = new TextBlock() { Text = labelB.ToString("N2"), Foreground = bBrush };

                tickA.SetValue(Canvas.LeftProperty, -40.0);
                tickA.SetValue(Canvas.TopProperty, yPosition - 10);

                tickB.SetValue(Canvas.RightProperty, -40.0);
                tickB.SetValue(Canvas.TopProperty, yPosition - 10);

                var seriesALabel = new Grid()
                {
                    Height = chartHeight,
                    Children =
                    {
                        new TextBlock()
                        {
                            LayoutTransform = new RotateTransform(-90),
                            Text = SeriesALabel,
                            Foreground = aBrush,
                            VerticalAlignment = VerticalAlignment.Center
                        }
                    }
                };

                var seriesBLabel = new Grid()
                {
                    Height = chartHeight,
                    Children =
                    {
                        new TextBlock()
                        {
                            LayoutTransform = new RotateTransform(90),
                            Text = SeriesBLabel,
                            Foreground = bBrush,
                            VerticalAlignment = VerticalAlignment.Center
                        }
                    }
                };

                seriesALabel.SetValue(Canvas.LeftProperty, -60.0);
                seriesBLabel.SetValue(Canvas.RightProperty, -60.0);

                chartArea.Children.Add(line);
                chartArea.Children.Add(tickA);
                chartArea.Children.Add(tickB);
                chartArea.Children.Add(seriesALabel);
                chartArea.Children.Add(seriesBLabel);

                yPosition -= yShift;
                labelA += labelAIncrement;
                labelB += labelBIncrement;
            }

            drawChart();
        }

        void drawChart()
        {
            pointsA.Clear();
            pointsB.Clear();
            double xIncrement = chartWidth / SeriesA.Count;
            double xPosition = 20;

            for (int i = 0; i < SeriesA.Count; i++)
            {
                var pointA = new Point() { X = xPosition };
                pointA.Y = (maxA - SeriesA[i]) * chartHeight / (maxA - minA);
                pointsA.Add(pointA);

                var pointB = new Point() { X = xPosition };
                pointB.Y = (maxB - SeriesB[i]) * chartHeight / (maxB - minB);
                pointsB.Add(pointB);

                var sgA = new StreamGeometry();
                var sgB = new StreamGeometry();
                using(var sgc = sgA.Open())
                {
                    sgc.BeginFigure(pointA, false, true);
                    sgc.LineTo(pointA, true, false);
                }

                using (var sgc = sgB.Open())
                {
                    sgc.BeginFigure(pointB, false, true);
                    sgc.LineTo(pointB, true, false);
                }

                var brushA = SeriesA[i] < 0 ? Brushes.Red : Brushes.Green;
                var brushB = SeriesB[i] < 0 ? Brushes.Red : Brushes.Green;

                chartArea.Children.Add(new Path() { Data = sgA, Stroke = brushA, StrokeThickness = 7, ToolTip = $"{SeriesALabel}: {SeriesA[i]}" });
                chartArea.Children.Add(new Path() { Data = sgB, Stroke = brushB, StrokeThickness = 7, ToolTip = $"{SeriesBLabel}: {SeriesB[i]}" });

                if (IsStampVisible)
                {
                    var label = new TextBlock() { Text = YearQ[i], LayoutTransform = new RotateTransform(-90) };
                    label.SetValue(Canvas.BottomProperty, -45.0);
                    label.SetValue(Canvas.LeftProperty, xPosition - 10);
                    chartArea.Children.Add(label);
                }

                xPosition += xIncrement;
            }
            chartArea.Children.Add(new Polyline() { Points = pointsA, Stroke = aBrush, StrokeThickness = thickness });
            chartArea.Children.Add(new Polyline() { Points = pointsB, Stroke = bBrush, StrokeThickness = thickness });
        }
    }
}
