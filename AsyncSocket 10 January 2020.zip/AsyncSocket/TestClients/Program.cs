﻿using Data;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TestClients
{
    class Program
    {
        static void Main(string[] args)
        {
            int numClient = 30000;
            var clients = new List<Client>(numClient);
            for (int i = 0; i < numClient; i++) clients.Add(new Client("C" + i));
         
            Parallel.ForEach(clients, (i) => i.Connect());
            Console.ReadKey();        
        }
    }

    class Client
    {
        SocketAsyncEventArgs receiver, sender;
        IPEndPoint receiverPort, senderPort;
        byte[] receiverInfo = new byte[Constants.infoBuffLength];
        byte[] senderInfo = new byte[Constants.infoBuffLength];

        public Client(string clientName)
        {
            var buffer = Encoding.ASCII.GetBytes(clientName);
            Buffer.BlockCopy(buffer, 0, receiverInfo, 0, buffer.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(true), 0, receiverInfo, 9, 1);

            Buffer.BlockCopy(buffer, 0, senderInfo, 0, buffer.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(false), 0, senderInfo, 9, 1);

            receiverPort = new IPEndPoint(IPAddress.Parse(Constants.host), Constants.receiverPort);
            senderPort = new IPEndPoint(IPAddress.Parse(Constants.host), Constants.senderPort);

            receiver = new SocketAsyncEventArgs() { AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) };
            sender = new SocketAsyncEventArgs() { AcceptSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) };
        }

        public void Connect()
        {
            receiver.AcceptSocket.Connect(receiverPort);
            receiver.AcceptSocket.Send(receiverInfo);

            sender.AcceptSocket.Connect(senderPort);
            sender.AcceptSocket.Send(senderInfo);
        }
    }
}
