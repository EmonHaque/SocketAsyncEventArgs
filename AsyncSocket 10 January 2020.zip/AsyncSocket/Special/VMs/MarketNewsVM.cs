﻿using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Client.VMs
{
    public class MarketNewsVM : INotifyPropertyChanged
    {
        MessageHeader header;
        static int itemCode;
        public static int ItemCode { get => itemCode; set { itemCode = value; OnStaticPropertyChanged(); } }

        string draftNews;
        public string DraftNews { get => draftNews; set { draftNews = value; OnPropertyChanged(); } }

        public Command Add { get; set; }
        public Command Send { get; set; }
        public AsyncObsetion<NewsItem> NewsList { get; set; }

        public MarketNewsVM()
        {
            header = new MessageHeader() { Type = Message.News};
            NewsList = new AsyncObsetion<NewsItem>();
            Add = new Command(Add2List, (o) => !String.IsNullOrEmpty(DraftNews));
            Send = new Command(SendNews, (o) => NewsList.Count > 0);
        }

        void Add2List(object obj)
        {
            NewsList.Insert(0, new NewsItem()
            {
                ItemName = ClientCode.Items.First(x => x.Id == ItemCode).Name,
                NewsFinal = DraftNews
            });
            DraftNews = null;
        }

        void SendNews(object obj)
        {
            var time = DateTime.Now;
            var bufferList = new List<ArraySegment<byte>>();
            var bufferSize = NewsList.Count * Constants.newsSize;
            header.Size = bufferSize;
            bufferList.Add(PacMan<MessageHeader>.Pack(header));
            foreach (var item in NewsList)
            {
                bufferList.Add(PacMan<News>.Pack(new News()
                {
                    Time = time.Hour +":"+ time.Minute,
                    ItemCode = ClientCode.Items.First(x => x.Name == item.ItemName).Id,
                    Feed = item.NewsFinal
                }));
            }
            ClientCode.sendArgs.AcceptSocket.Send(bufferList);
            NewsList.Clear();
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }
}
