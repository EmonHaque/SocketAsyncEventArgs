﻿using System.Windows.Controls;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for CustomerTrade.xaml
    /// </summary>
    public partial class CustomerTrade : UserControl
    {
        public CustomerTrade()
        {
            InitializeComponent();
        }
    }
}
