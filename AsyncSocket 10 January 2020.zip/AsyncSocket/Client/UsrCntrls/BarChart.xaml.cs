﻿using Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client.UsrCntrls
{
    public partial class BarChart : UserControl
    {
        #region Dependency Properties
        public IEnumerable<Issue> Series
        {
            get { return (IEnumerable<Issue>)GetValue(SeriesProperty); }
            set { SetValue(SeriesProperty, value); }
        }

        public static readonly DependencyProperty SeriesProperty =
            DependencyProperty.Register("Series", typeof(IEnumerable<Issue>), typeof(BarChart), new PropertyMetadata(null, setMax));

        static void setMax(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var instance = d as BarChart;
            instance.chartArea.Children.Clear();
            instance.count = instance.Series.Count();
            if(instance.count > 0)
            {
                instance.max = instance.Series.Max(x => x.Percent);
                instance.drawGrid();
            }
            else
            {
                var text = new Grid()
                {
                    Height = instance.chartHeight,
                    Width = instance.chartWidth,
                    Children =
                    {
                        new TextBlock()
                        {
                            Text = "It'd entered the market by offloading securities and haven't yet had any kind of issue",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center,
                            TextWrapping = TextWrapping.Wrap
                        }
                    }
                };
                instance.chartArea.Children.Add(text);
            }
        }
        #endregion

        int numGridLine = 4;
        int count;
        double chartWidth, chartHeight, max;
        public Brush RightBrush { get; set; }
        public Brush NewBrush { get; set; }
        public Brush CapitalisedBrush { get; set; }

        public BarChart()
        {
            NewBrush = Brushes.Blue;
            RightBrush = Brushes.Green;
            CapitalisedBrush = Brushes.Red;
            InitializeComponent();
            SizeChanged += resized;
        }

        void resized(object sender, SizeChangedEventArgs e)
        {
            chartArea.Children.Clear();
            chartWidth = chartArea.ActualWidth;
            chartHeight = chartArea.ActualHeight;
            if(count > 0) drawGrid();
            else
            {
                var text = new Grid()
                {
                    Height = chartHeight,
                    Width = chartWidth,
                    Children =
                    {
                        new TextBlock()
                        {
                            Text = "It'd entered the market by offloading securities and haven't yet had any kind of issue",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center,
                            TextWrapping = TextWrapping.Wrap
                        }
                    }
                };
                chartArea.Children.Add(text);
            }

        }

        void drawGrid()
        {
            var yShift = chartHeight / numGridLine;
            double yPosition = chartHeight;
            double labelA = 0;
            double labelAIncrement = max / numGridLine;

            for (int i = 0; i <= numGridLine; i++)
            {
                var line = new Line() { X1 = 0, X2 = chartWidth, Y1 = yPosition, Y2 = yPosition, Stroke = Brushes.Black, StrokeThickness = 0.25 };
                var tickA = new TextBlock() { Text = labelA.ToString("N2") };
                tickA.SetValue(Canvas.LeftProperty, -40.0);
                tickA.SetValue(Canvas.TopProperty, yPosition - 10);
                chartArea.Children.Add(line);
                chartArea.Children.Add(tickA);
                yPosition -= yShift;
                labelA += labelAIncrement;
            }
            drawChart();
        }

        void drawChart()
        {
            var count = Series.Count();
            double xIncrement = chartWidth / count;
            double xPosition = 0;

            foreach (var item in Series)
            {
                Brush brush = null;
                string text = string.Empty;
                switch (item.Type)
                {
                    case IssueType.New: brush = NewBrush; text = "New: "; break;
                    case IssueType.Capitalised: brush = CapitalisedBrush; text = "Capitalised: "; break;
                    case IssueType.Right: brush = RightBrush; text = "Right: "; break;
                }
                var border = new Border()
                {
                    Width = 0.9 * xIncrement,
                    Height = item.Percent * chartHeight / max,
                    Background = brush,
                    CornerRadius = new CornerRadius(20, 20, 0, 0),
                    ToolTip = text + item.Percent.ToString("N2")
                };
                border.SetValue(Canvas.LeftProperty, xPosition);
                border.SetValue(Canvas.BottomProperty, 0.0);

                var label = new TextBlock() { Text = item.Year.ToString(), LayoutTransform = new RotateTransform(-90) };
                label.SetValue(Canvas.BottomProperty, -30.0);
                label.SetValue(Canvas.LeftProperty, xPosition + border.Width / 2);

                chartArea.Children.Add(border);
                chartArea.Children.Add(label);
                xPosition += xIncrement;
            }
        }
    }
}
