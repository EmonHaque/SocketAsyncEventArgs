﻿using Data;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Client.VMs
{
    public class CustomerTradeVM : INotifyPropertyChanged
    {
        public Command Print { get; set; }

        FlowDocument doc;

        static IEnumerable<int> customersCode;
        public static IEnumerable<int> CustomersCode { get => customersCode; set { customersCode = value; OnStaticPropertyChanged(); } }

        static IEnumerable<TradeByCustomer> trade;
        public static IEnumerable<TradeByCustomer> Trade { get => trade; set { trade = value; OnStaticPropertyChanged(); } }

        static int customerCode;
        public static int CustomerCode
        {
            get => customerCode;
            set
            {
                customerCode = value;
                UpdateCustomerTransaction(value);
                OnStaticPropertyChanged();
            }
        }

        public CustomerTradeVM()
        {
            Print = new Command(PrintDoc, (o) => true);
            ClientCode.OnConnected += Subscribe;
            ClientCode.OnDisconnected += Unsubscribe;


        }

        void Subscribe()
        {
            ClientCode.MyExecutedChanged += Update;
        }

        void Unsubscribe()
        {
            ClientCode.MyExecutedChanged -= Update;
        }

        void Update(AllOrder order)
        {
            if (order.PartyCode == CustomerCode) UpdateCustomerTransaction(CustomerCode);
        }

        static void UpdateCustomerTransaction(int code)
        {
            Trade = ClientCode.MyExecutedOrders.Where(x => x.PartyCode == code)
                                                   .Select(x => new TradeByCustomer()
                                                   {
                                                       TransNo = x.TransactionNo,
                                                       Price = x.Price,
                                                       Type = x.Type,
                                                       OrderNo = x.Type == "Buy" ? x.BuyOrderNo : x.SellOrderNo,
                                                       Quantity = x.QtyTraded,
                                                       ValueTraded = (decimal)(x.QtyTraded * x.Price)
                                                   });
        }

        void PrintDoc(object obj)
        {
            doc = new FlowDocument();
            doc.PageWidth = 96 * 8.5;
            doc.PageHeight = 96 * 11.7;
            doc.PagePadding = new Thickness(96, 96 * 1.7, 96, 96 * 1.1);

            var table = new Table();
            table.CellSpacing = 0;

            for (int i = 0; i < 6; i++)
            {
                var column = new TableColumn();
                if (i < 3) column.Width = new GridLength(70);
                else column.Width = new GridLength(138);
                table.Columns.Add(column);
            }

            var rowNum = 1;
            foreach (var item in Trade)
            {
                var rowGroup = new TableRowGroup();
                var row = new TableRow();

                row.Cells.Add(new TableCell(new Paragraph(new Run(item.TransNo.ToString()))) { TextAlignment = TextAlignment.Center });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.OrderNo.ToString()))) { TextAlignment = TextAlignment.Center });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Type))) { TextAlignment = TextAlignment.Center });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Price.ToString("N2")))) { TextAlignment = TextAlignment.Right });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.Quantity.ToString("N0")))) { TextAlignment = TextAlignment.Right });
                row.Cells.Add(new TableCell(new Paragraph(new Run(item.ValueTraded.ToString("N2")))) { TextAlignment = TextAlignment.Right });

                if (rowNum % 2 == 0) row.Background = new SolidColorBrush(Colors.LightGray);

                rowGroup.Rows.Add(row);
                table.RowGroups.Add(rowGroup);
                rowNum++;
            }
            doc.Blocks.Add(table);

            PrintDialog dialog = new PrintDialog();
            dialog.CurrentPageEnabled = true;
            dialog.UserPageRangeEnabled = true;
            if (dialog.ShowDialog() == true)
            {
                var paginator = new FlowPaginator(doc, CustomerCode);
                dialog.PrintDocument(paginator, "");
            }
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class FlowPaginator : DocumentPaginator
    {
        string[] headers = { "Trans No.", "Order No.", "Type", "Price", "Quantity", "Value" };
        int code;
        DocumentPaginator paginator;
        public FlowPaginator(FlowDocument doc, int customerCode)
        {
            code = customerCode;
            paginator = ((IDocumentPaginatorSource)doc).DocumentPaginator;
        }
        public override bool IsPageCountValid => paginator.IsPageCountValid;
        public override int PageCount => paginator.PageCount;
        public override Size PageSize { get => paginator.PageSize; set => paginator.PageSize = value; }
        public override IDocumentPaginatorSource Source => paginator.Source;

        public override DocumentPage GetPage(int pageNumber)
        {
            var oldPage = paginator.GetPage(pageNumber);

            var visual = new ContainerVisual();
            var header = new DrawingVisual();
            var footer = new DrawingVisual();

            #region Heading
            var heading = new Grid() { Width = oldPage.Size.Width - 2 * 96 };
            heading.RowDefinitions.Add(new RowDefinition());
            heading.RowDefinitions.Add(new RowDefinition());
            heading.ColumnDefinitions.Add(new ColumnDefinition());
            heading.ColumnDefinitions.Add(new ColumnDefinition());

            var t1 = new TextBlock() { Text = "Trade Report", FontSize = 24, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center };
            var t2 = new TextBlock() { Text = "Customer Code: " + code, FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Left };
            var t3 = new TextBlock() { Text = "Date: " + DateTime.Now.ToShortDateString(), FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Right };

            Grid.SetColumn(t1, 0); Grid.SetRow(t1, 0); Grid.SetColumnSpan(t1, 2);
            Grid.SetColumn(t2, 0); Grid.SetRow(t2, 1);
            Grid.SetColumn(t3, 1); Grid.SetRow(t3, 1);

            heading.Children.Add(t1);
            heading.Children.Add(t2);
            heading.Children.Add(t3);
            heading.Measure(new Size(oldPage.Size.Width, oldPage.Size.Height));
            heading.Arrange(new Rect(heading.DesiredSize));
            var headingSize = new Size() { Height = heading.ActualHeight, Width = heading.ActualWidth };

            #endregion

            #region TableHeader

            var tableHeader = new Grid() { Width = oldPage.Size.Width - 2 * 96 };
            var border = new Border()
            {
                Background = new SolidColorBrush(Colors.LightGray),
                BorderBrush = new SolidColorBrush(Colors.Black),
                BorderThickness = new Thickness(0, 1, 0, 1),
                Child = tableHeader
            };

            for (int i = 0; i < headers.Length; i++)
            {
                tableHeader.ColumnDefinitions.Add(new ColumnDefinition());
                var head = new TextBlock() { Text = headers[i], FontWeight = FontWeights.Bold };

                if (i > 2)
                {
                    tableHeader.ColumnDefinitions[i].Width = new GridLength(138);
                    head.HorizontalAlignment = HorizontalAlignment.Right;
                }
                else
                {
                    tableHeader.ColumnDefinitions[i].Width = new GridLength(70);
                    head.HorizontalAlignment = HorizontalAlignment.Center;
                }

                Grid.SetColumn(head, i);
                tableHeader.Children.Add(head);
            }

            border.Measure(new Size(oldPage.Size.Width, oldPage.Size.Height));
            border.Arrange(new Rect(border.DesiredSize));
            var borderSize = new Size() { Height = border.ActualHeight, Width = border.ActualWidth };
            #endregion

            using (var dc = header.RenderOpen())
            {
                dc.DrawRectangle(new VisualBrush(heading), null, new Rect(new Point(96, 96), headingSize));
                dc.DrawRectangle(new VisualBrush(border), null, new Rect(new Point(96, 96 * 1.55), borderSize));
            }

            using (var dc = footer.RenderOpen())
            {
                var text = new TextBlock() { Text = "Page: " + (pageNumber + 1) };
                text.Measure(new Size(oldPage.Size.Width, oldPage.Size.Height));
                text.Arrange(new Rect(text.DesiredSize));
                var texSize = new Size() { Height = text.ActualHeight, Width = text.ActualWidth };
                dc.DrawRectangle(new VisualBrush(text), null, new Rect(oldPage.Size.Width - 96, oldPage.Size.Height - 96, texSize.Width, texSize.Height));
            }

            visual.Children.Add(header);
            visual.Children.Add(oldPage.Visual);
            visual.Children.Add(footer);

            return new DocumentPage(visual);
        }
    }
}
