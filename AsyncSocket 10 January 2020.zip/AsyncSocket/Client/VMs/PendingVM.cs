﻿using Data;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;

namespace Client.VMs
{
    public class PendingVM : INotifyPropertyChanged, IDataErrorInfo
    {
        Window Dialog;
        DisplayPending edited;
        IEnumerable<DisplayPending> pendings;
        MessageHeader header;
        string price, quantity;

        public Command Modify { get; set; }
        public Command Delete { get; set; }
        public Command Update { get; set; }
        public Command Close { get; set; }

        public IEnumerable<DisplayPending> Pendings { get => pendings; set { pendings = value; OnPropertyChanged(); } }
        public DisplayPending Edited { get => edited; set { edited = value; OnPropertyChanged(); } }
        public string Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }
        public string Price { get => price; set { price = value; OnPropertyChanged(); } }

        public PendingVM()
        {
            header = new MessageHeader() { Type = Message.Trade };

            ClientCode.OnConnected += Subscribe;
            ClientCode.OnDisconnected += Unsubscribe;

            Modify = new Command(ModifyOrder, (o) => true);
            Delete = new Command(DeleteOrder, (o) => true);
            Update = new Command(UpdateOrder, (o) => Errors.Count == 0);
            Close = new Command(CloseDialog, (o) => Errors.Count == 0);
        }

        void Subscribe()
        {
            ClientCode.PendingsChanged += UpdateList;
        }

        void Unsubscribe()
        {
            ClientCode.PendingsChanged -= UpdateList;
        }

        void CloseDialog(object obj) => Dialog.Close();

        void UpdateList()
        {
            Pendings = ClientCode.PendingOrders.Select(x => new DisplayPending()
            {
                ItemCode = ClientCode.Items.First(y => y.Id == x.ItemCode).Id,
                ItemName = ClientCode.Items.First(y => y.Id == x.ItemCode).Name,
                OrderNo = x.BuyOrderNo == 0 ? x.SellOrderNo : x.BuyOrderNo,
                OrderType = x.OrderType == OrderType.Buy ? "Buy" : "Sell",
                PartyCode = x.PartyCode,
                Price = x.Price,
                Quantity = x.Quantity
            });
        }

        void ModifyOrder(object obj)
        {
            if (obj != null)
            {
                Edited = obj as DisplayPending;
                var item = ClientCode.Items.First(x => x.Id == Edited.ItemCode);
                Edited.Cap = item.Cap;
                Edited.Floor = item.Floor;
                Price = Edited.Price.ToString();
                Quantity = Edited.Quantity.ToString();
                ShowDialog();
            }
        }

        void UpdateOrder(object obj)
        {
            Dialog.Close();
            Edited.Price = Convert.ToSingle(Price);
            Edited.Quantity = Convert.ToInt32(Quantity);

            var buyOrder = Edited.OrderType == "Buy";
            var o = buyOrder ? ClientCode.PendingOrders.Where(x => x.BuyOrderNo == Edited.OrderNo).FirstOrDefault()
                             : ClientCode.PendingOrders.Where(x => x.SellOrderNo == Edited.OrderNo).FirstOrDefault();

            bool updatable = false;
            if (o != null) updatable = o.Price != Edited.Price || o.Quantity != Edited.Quantity;
            if (updatable)
            {
                var order = new AllOrder()
                {
                    Action = Data.Action.Modify,
                    BrokerName = o.BrokerName,
                    OrderType = o.OrderType,
                    ItemCode = o.ItemCode,
                    PartyCode = o.PartyCode,
                    BuyOrderNo = o.BuyOrderNo,
                    SellOrderNo = o.SellOrderNo,
                    Price = Edited.Price,
                    Quantity = Edited.Quantity
                };

                ClientCode.sendArgs.AcceptSocket.Send(new List<ArraySegment<byte>>()
                {
                    PacMan<MessageHeader>.Pack(header),
                    PacMan<AllOrder>.PackOrder(order)
                });
            }
        }

        void DeleteOrder(object obj)
        {
            Edited = obj as DisplayPending;
            var buyOrder = Edited.OrderType == "Buy";
            var o = buyOrder ? ClientCode.PendingOrders.Where(x => x.BuyOrderNo == Edited.OrderNo).FirstOrDefault()
                             : ClientCode.PendingOrders.Where(x => x.SellOrderNo == Edited.OrderNo).FirstOrDefault();
            if (o != null)
            {
                var order = new AllOrder()
                {
                    Action = Data.Action.Delete,
                    BrokerName = o.BrokerName,
                    OrderType = o.OrderType,
                    BuyOrderNo = o.BuyOrderNo,
                    SellOrderNo = o.SellOrderNo
                };

                ClientCode.sendArgs.AcceptSocket.Send(new List<ArraySegment<byte>>()
                {
                    PacMan<MessageHeader>.Pack(header),
                    PacMan<AllOrderStruct>.PackOrder(order)
                });
            }
        }

        void ShowDialog()
        {
            Dialog = new Window()
            {
                Title = "Custom Dialog",
                WindowStyle = WindowStyle.None,
                Content = new UsrCntrls.UserDialog(),
                DataContext = this,
                SizeToContent = SizeToContent.WidthAndHeight,
                ShowInTaskbar = false,
                ResizeMode = ResizeMode.NoResize,
                Owner = Application.Current.MainWindow,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };
            Dialog.MouseLeftButtonDown += (o, e) => Dialog.DragMove();
            Dialog.ShowDialog();
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion

        #region IDataErrorInfo
        public string Error => null;

        List<string> errors;
        public List<string> Errors
        {
            get
            {
                errors = new List<string>();
                if (!String.IsNullOrWhiteSpace(this["Quantity"])) errors.Add(this["Quantity"]);
                if (!String.IsNullOrWhiteSpace(this["Price"])) errors.Add(this["Price"]);
                return errors;
            }
        }

        public string this[string columnName]
        {
            get
            {
                string error = string.Empty;
                int x; float y;
                if (columnName == "Quantity")
                {
                    if (!int.TryParse(Quantity, out x)) error = "Invalid";
                    else if (x < 1) error = "Invalid";
                }
                else if (columnName == "Price")
                {
                    if (!float.TryParse(Price, out y)) error = "Invalid";
                    else if (y < Edited.Floor || y > Edited.Cap) error = "Invalid";
                }
                return error;
            }
        }
        #endregion
    }
}
