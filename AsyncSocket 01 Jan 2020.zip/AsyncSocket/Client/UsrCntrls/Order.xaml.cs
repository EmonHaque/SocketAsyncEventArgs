﻿using System.Windows.Controls;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for Order.xaml
    /// </summary>
    public partial class Order : UserControl
    {
        public Order()
        {
            InitializeComponent();
        }
    }
}
