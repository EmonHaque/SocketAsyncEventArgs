﻿using System.Windows.Controls;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for UserDialog.xaml
    /// </summary>
    public partial class UserDialog : UserControl
    {
        public UserDialog()
        {
            InitializeComponent();
        }
    }
}
