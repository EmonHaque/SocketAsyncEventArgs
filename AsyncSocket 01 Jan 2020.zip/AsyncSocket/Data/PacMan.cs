﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Data
{
    public class PacMan<Type> where Type : new()
    {
        public static byte[] Pack(Type t)
        {
            int size = Marshal.SizeOf(t);
            byte[] array = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(t, ptr, false);
            Marshal.Copy(ptr, array, 0, size);
            Marshal.FreeHGlobal(ptr);
            return array;
        }

        public static Type Unpack(byte[] ar)
        {
            Type t = new Type();
            int size = Marshal.SizeOf(t);
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.Copy(ar, 0, ptr, size);
            t = (Type)Marshal.PtrToStructure(ptr, t.GetType());
            Marshal.FreeHGlobal(ptr);
            return t;
        }

        public static AllOrder UnpackOrder(byte[] ar)
        {
            var order = new AllOrder();
            order.TransactionNo = BitConverter.ToInt32(ar.Take(4).ToArray());
            order.SellOrderNo = BitConverter.ToInt32(ar.Skip(4).Take(4).ToArray());
            order.BuyOrderNo = BitConverter.ToInt32(ar.Skip(8).Take(4).ToArray());
            order.Action = (Action)BitConverter.ToInt32(ar.Skip(12).Take(4).ToArray());
            order.ItemCode = BitConverter.ToInt32(ar.Skip(16).Take(4).ToArray());
            order.OrderType = (OrderType)BitConverter.ToInt32(ar.Skip(20).Take(4).ToArray());
            order.Quantity = BitConverter.ToInt32(ar.Skip(24).Take(4).ToArray());
            order.Price = BitConverter.ToSingle(ar.Skip(28).Take(4).ToArray());
            order.PartyCode = BitConverter.ToInt32(ar.Skip(32).Take(4).ToArray());
            order.BrokerName = Encoding.ASCII.GetString(ar.Skip(36).Take(10).ToArray()).Trim('\0');
            order.BrokerBought = Encoding.ASCII.GetString(ar.Skip(46).Take(10).ToArray()).Trim('\0');
            order.BrokerSold = Encoding.ASCII.GetString(ar.Skip(56).Take(10).ToArray()).Trim('\0');
            order.PartySold = BitConverter.ToInt32(ar.Skip(66).Take(4).ToArray());
            order.PartyBought = BitConverter.ToInt32(ar.Skip(70).Take(4).ToArray());
            order.QtyTraded = BitConverter.ToInt32(ar.Skip(74).Take(4).ToArray());
            order.ExType = (ExecutionType)BitConverter.ToInt32(ar.Skip(78).Take(4).ToArray());
            order.ExecutionTime = Encoding.ASCII.GetString(ar.Skip(82).Take(6).ToArray()).Trim('\0');
            return order;
        }

        public static byte[] PackOrder(AllOrder order)
        {
            var array = new byte[Constants.orderSize];

            var brokerName = Encoding.ASCII.GetBytes(order.BrokerName);
            var brokerBought = Encoding.ASCII.GetBytes(order.BrokerBought);
            var brokerSold = Encoding.ASCII.GetBytes(order.BrokerSold);
            var execTime = Encoding.ASCII.GetBytes(order.ExecutionTime);

            Buffer.BlockCopy(BitConverter.GetBytes(order.TransactionNo), 0, array, 0, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.SellOrderNo), 0, array, 4, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.BuyOrderNo), 0, array, 8, 4);
            Buffer.BlockCopy(BitConverter.GetBytes((int)order.Action), 0, array, 12, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.ItemCode), 0, array, 16, 4);
            Buffer.BlockCopy(BitConverter.GetBytes((int)order.OrderType), 0, array, 20, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.Quantity), 0, array, 24, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.Price), 0, array, 28, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.PartyCode), 0, array, 32, 4);
            Buffer.BlockCopy(brokerName, 0, array, 36, brokerName.Length);
            Buffer.BlockCopy(brokerBought, 0, array, 46, brokerBought.Length);
            Buffer.BlockCopy(brokerSold, 0, array, 56, brokerSold.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(order.PartySold), 0, array, 66, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.PartyBought), 0, array, 70, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(order.QtyTraded), 0, array, 74, 4);
            Buffer.BlockCopy(BitConverter.GetBytes((int)order.ExType), 0, array, 78, 4);
            Buffer.BlockCopy(execTime, 0, array, 82, execTime.Length);

            return array;
        }

        public static Type[] ListToArray<T>(List<T> list)
        {
            var fields = typeof(Type).GetFields();
            var properties = typeof(T).GetProperties();
            var array = new Type[list.Count];

            for (int i = 0; i < array.Length; i++)
            {
                foreach (var field in fields)
                {
                    var value = properties.First(x => x.Name == field.Name).GetValue(list[i]);
                    field.SetValueDirect(__makeref(array[i]), value);
                }
            }
            return array;
        }

        public static List<T> ArrayToList<T>(Type[] array) where T : new()
        {
            var fields = typeof(Type).GetFields();
            var properties = typeof(T).GetProperties();
            var list = new List<T>(array.Length);

            for (int i = 0; i < array.Length; i++)
            {
                var obj = new T();
                foreach (var property in properties)
                {
                    var value = fields.First(x => x.Name == property.Name).GetValue(array[i]);
                    property.SetValue(obj, value);
                }
                list.Add(obj);
            }
            return list;
        }
    }
}
