﻿using System.Windows.Controls;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for MakeNews.xaml
    /// </summary>
    public partial class MakeNews : UserControl
    {
        public MakeNews()
        {
            InitializeComponent();
        }
    }
}
