﻿using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Server
{
    public class ServerCode : INotifyPropertyChanged
    {
        Socket server;
        bool isListening;
        string status;
        int orderNo = 1;
        int transactionNo = 1;

        FileServer updateServer;

        public ICommand Start { get; set; }
        public ICommand Stop { get; set; }
        public bool IsListening { get => isListening; set { isListening = value; OnPropertyChanged(); } }
        public string Status { get => status; set { status = value; OnPropertyChanged(); } }
        public AsyncObsetion<Client> Clients { get; set; }
        public FileServer UpdateServer { get => updateServer; set { updateServer = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler PropertyChanged;

        public AsyncObsetion<Item> Items = new AsyncObsetion<Item>();
        public AsyncObsetion<AllOrder> BuyOrders = new AsyncObsetion<AllOrder>();
        public AsyncObsetion<AllOrder> SellOrders = new AsyncObsetion<AllOrder>();
        public AsyncObsetion<Issue> Issued = new AsyncObsetion<Issue>();

        IList<ArraySegment<byte>> ItemsArray = new List<ArraySegment<byte>>();
        IList<ArraySegment<byte>> IssuesArray = new List<ArraySegment<byte>>();
        IList<ArraySegment<byte>> NewsArray = new List<ArraySegment<byte>>();
        IList<ArraySegment<byte>> ExecutedArray = new List<ArraySegment<byte>>();

        public ServerCode()
        {
            //UpdateServer = new FileServer();
            StartServer(null);
            //Task.Run(() => UpdateServer.StartServer(null));
            GetItems();
            GetIssues();
            PackItemsAndIssues();

            Clients = new AsyncObsetion<Client>();
            Start = new Command(StartServer, (o) => !IsListening);
            Stop = new Command(StopServer, (o) => IsListening);
           
        }

        void GetItems()
        {
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
            {
                float owners = rand.Next(0, 100);
                float govt = rand.Next(0, 100);
                float foreign = rand.Next(0, 100);
                float inst = rand.Next(0, 100);
                float pub = rand.Next(0, 100);

                float sum = (owners + govt + foreign + inst + pub) / 100;
                owners /= sum;
                govt /= sum;
                foreign /= sum;
                inst /= sum;
                pub /= sum;

                var perSec = new List<PerSecurityFinancials>();

                for (int j = 2016; j < 2020; j++)
                {
                    for (int k = 1; k < 5; k++)
                    {
                        perSec.Add(new PerSecurityFinancials()
                        {
                            YQ = j.ToString() + "/" + k.ToString(),
                            EPS = rand.Next(-10,30),
                            NAV = rand.Next(-100,300),
                            Cash =rand.Next(1,300),
                            Debt = rand.Next(0,500)
                        });
                    }
                }

                var dividends = new List<Dividend>();
                for (int j = 2014; j < 2019; j++)
                {
                    dividends.Add(new Dividend()
                    {
                        Year = j,
                        Cash = (float)rand.NextDouble() * 100
                    });

                }

                Items.Add(new Item() 
                { 
                    Id = i + 1, 
                    Name = "Item " + (i + 1),
                    Floor = rand.Next(10, 15),
                    Cap = rand.Next(15, 20),
                    Securities = rand.Next(1, 5) * 1000000,
                    Owners = owners,
                    Govt = govt,
                    Foreign = foreign,
                    Institutions = inst,
                    Public = pub,
                    PerSecurity = perSec,
                    Dividends = dividends,
                    InitialSecurity = rand.Next(1, 10) * 100000
                });
            }
        }

        void GetIssues()
        {
            var random = new Random();
            for (int i = 0; i < 10; i++)
            {
                if(i != 1)
                {
                    var times = random.Next(1, 20);
                    for (int j = 0; j < times; j++)
                    {
                        var year = random.Next(1990, 2020);
                        var issueType = (IssueType)random.Next(0, 3);
                        Issued.Add(new Issue()
                        {
                            Id = i + 1,
                            Percent = (float)random.NextDouble() * 200,
                            Type = issueType,
                            Year = year
                        });
                    }
                }               
            }
            Issued = new AsyncObsetion<Issue>(Issued.OrderBy(x => x.Year));
        }

        void PackItemsAndIssues()
        {
            foreach (var item in Items)
            {
                ItemsArray.Add(PacMan<ItemStruct>.Pack(new ItemStruct()
                {
                    Id = item.Id,
                    Name = item.Name,
                    Cap = item.Cap,
                    Floor = item.Floor,
                    Securities = item.Securities,
                    Owners = item.Owners,
                    Govt = item.Govt,
                    Institutions = item.Institutions,
                    Foreign = item.Foreign,
                    Public = item.Public,
                    PerSecurity = PacMan<PerSecurityFinancialsStruct>.ListToArray(item.PerSecurity),
                    Dividends = PacMan<DividendStruct>.ListToArray(item.Dividends),
                    InitialSecurity = item.InitialSecurity
                }));
            }

            foreach (var issue in Issued)
            {
                IssuesArray.Add(PacMan<IssueStruct>.Pack(new IssueStruct()
                {
                    Id = issue.Id,
                    Percent = issue.Percent,
                    Type = issue.Type,
                    Year = issue.Year
                }));
            }
        }

        void StartServer(object obj)
        {
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(new IPEndPoint(0, Constants.tradePort));
            server.Listen(0);
            IsListening = true;
            Status = "Listening";
            Accept();
        }

        void Accept()
        {
            var arg = new SocketAsyncEventArgs();
            arg.Completed += Accepted;
            if (!server.AcceptAsync(arg)) Accepted(null, arg);
        }

        void Accepted(object sender, SocketAsyncEventArgs e)
        {
            if(e.SocketError == SocketError.Success)
            {
                e.Completed -= Accepted;
                e.Completed += CheckInfo;
                SetBuffer(e, Constants.infoBuffLength);
                bool checkedInfo = e.AcceptSocket.ReceiveAsync(e);
                if (!checkedInfo) CheckInfo(null, e);
                Accept();
            }
            else if(e.SocketError == SocketError.OperationAborted)
            {
                e.Dispose();
                StopServer(null);
            }
        }

        void CheckInfo(object sender, SocketAsyncEventArgs e)
        {
            lock (Clients)
            {
                e.Completed -= CheckInfo;
                var info = PacMan<SockInfo>.Unpack(e.Buffer);
                var c = Clients.FirstOrDefault(x => x.Name == info.Name);
                if (c == null)
                {
                    c = new Client();
                    c.Name = info.Name;
                    Clients.Add(c);
                }

                if (info.RecvArg)
                {
                    c.SendArgs = e;
                    c.SendArgs.SetBuffer(null);
                    c.SendArgs.Completed += Sent;
                    SendLists(c);
                }
                else
                {
                    c.RecvArgs = e;
                    FixedBuffers token = new FixedBuffers();
                    c.RecvArgs.UserToken = token;
                    c.RecvArgs.SetBuffer(token.HeaderBuffer, 0, Constants.messageHeaderLength);
                    c.RecvArgs.Completed += Received;
                    if (!c.RecvArgs.AcceptSocket.ReceiveAsync(c.RecvArgs)) Received(null, c.RecvArgs);
                }
            }
        }

        void SendLists(Client c)
        {
            bool hasBuy = BuyOrders.Count > 0;
            bool hasSell = SellOrders.Count > 0;
            bool hasExec = ExecutedArray.Count > 0;
            bool hasNews = NewsArray.Count > 0;

            var header = new HeaderStruct()
            {
                HasBuy = hasBuy,
                HasSell = hasSell,
                HasExecuted = hasExec,
                HasNews = hasNews,

                ItemSize = ItemsArray.Count * Constants.itemSize,
                BuySize = BuyOrders.Count * Constants.orderSize,
                SellSize = SellOrders.Count * Constants.orderSize,
                ExecutedSize = ExecutedArray.Count * Constants.orderSize,
                NewsSize = NewsArray.Count * Constants.newsSize,
                IssueSize = IssuesArray.Count * Constants.issueSize
            };

            var array = new List<ArraySegment<byte>>();
            array.Add(PacMan<HeaderStruct>.Pack(header));

            array.AddRange(ItemsArray);

            if (hasBuy) PackOrder(BuyOrders, array);
            if (hasSell) PackOrder(SellOrders, array);
            if (hasExec) array.AddRange(ExecutedArray);
            if (hasNews) array.AddRange(NewsArray);
            array.AddRange(IssuesArray);
            c.SendArgs.AcceptSocket.Send(array);
        }

        void PackOrder(AsyncObsetion<AllOrder> orderType, List<ArraySegment<byte>> array)
        {
            foreach (var order in orderType)
            {
                array.Add(PacMan<AllOrderStruct>.Pack(new AllOrderStruct()
                {
                    TransactionNo = order.TransactionNo,
                    BrokerBought = order.BrokerBought,
                    BrokerName = order.BrokerName,
                    BrokerSold = order.BrokerSold,
                    Action = order.Action,
                    ItemCode = order.ItemCode,
                    BuyOrderNo = order.BuyOrderNo,
                    SellOrderNo = order.SellOrderNo,
                    OrderType = order.OrderType,
                    PartyBought = order.PartyBought,
                    PartyCode = order.PartyCode,
                    PartySold = order.PartySold,
                    Price = order.Price,
                    QtyTraded = order.QtyTraded,
                    Quantity = order.Quantity,
                    ExecutionTime = order.ExecutionTime
                }));
            }
        }

        void Received(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred > 0 && e.SocketError == SocketError.Success)
            {
                while (e.AcceptSocket.Available < Constants.messageHeaderLength) Thread.Sleep(10);
                var token = e.UserToken as FixedBuffers;
                var data = PacMan<MessageHeader>.Unpack(e.Buffer);
                byte[] array = null;
                if (data.Type == Message.News)
                {
                    SetBuffer(e, data.Size);
                    int read = e.AcceptSocket.Receive(e.Buffer);
                    while (read < data.Size) read += e.AcceptSocket.Receive(e.Buffer, read, data.Size - read, SocketFlags.None);
                    array = e.Buffer.ToArray();
                    Task.Run(() => BroadcastNews(array));
                }
                else
                {
                    e.SetBuffer(token.OrderBuffer, 0, Constants.orderSize);
                    int read = e.AcceptSocket.Receive(e.Buffer);
                    while (read < Constants.orderSize) read += e.AcceptSocket.Receive(e.Buffer, read, Constants.orderSize - read, SocketFlags.None);                    
                    var order = PacMan<AllOrder>.UnpackOrder(e.Buffer);
                    Task.Run(() => ProcessAndSend(order));
                }
                e.SetBuffer(token.HeaderBuffer, 0, Constants.messageHeaderLength);

                if (!e.AcceptSocket.ReceiveAsync(e)) Received(null, e);
            }
            else if (e.SocketError == SocketError.OperationAborted) StopServer(null);
            else RemoveClient(e);
        }

        void ProcessAndSend(AllOrder order)
        {
            lock (SellOrders)
            {
                lock (BuyOrders)
                {
                    var orderList = order.OrderType == OrderType.Buy ? BuyOrders : SellOrders;

                    switch (order.Action)
                    {
                        case Data.Action.Delete: DeleteIfExistis(orderList, order); break;
                        case Data.Action.Modify: if (IsReady4Execution(orderList, order)) Execute(Match4Execution(order), order); break;
                        case Data.Action.Add:
                            if (Match4Execution(order).Count() > 0) Execute(Match4Execution(order), order);
                            else
                            {
                                AddNewOrder(orderList, order);
                                orderNo++;
                            }
                            break;
                    }
                }
            }
        }

        void Execute(IEnumerable<AllOrder> matched, AllOrder order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var matchedList = buyOrder ? SellOrders : BuyOrders;
            var available = matched.Sum(x => x.Quantity);
            var ordered = order.Quantity;
            matched = buyOrder ? matched.OrderBy(x => x.Price).ThenBy(x => x.SellOrderNo)
                               : matched.OrderByDescending(x => x.Price).ThenBy(x => x.BuyOrderNo);

            if (order.Action == Data.Action.Add)
            {
                if (buyOrder) order.BuyOrderNo = orderNo;
                else order.SellOrderNo = orderNo;
            }

            foreach (var match in matched)
            {
                match.TransactionNo = transactionNo;

                match.Action = Data.Action.Execute;
                match.BrokerBought = buyOrder ? order.BrokerName : match.BrokerName;
                match.BrokerSold = buyOrder ? match.BrokerName : order.BrokerName;
                match.PartyBought = buyOrder ? order.PartyCode : match.PartyCode;
                match.PartySold = buyOrder ? match.PartyCode : order.PartyCode;
                var time = DateTime.Now;
                match.ExecutionTime = time.Hour + ":" + time.Minute;

                if (buyOrder) match.BuyOrderNo = order.BuyOrderNo;
                else match.SellOrderNo = order.SellOrderNo;

                if (match.Quantity <= ordered)
                {
                    match.ExType = ExecutionType.Full;
                    match.QtyTraded = match.Quantity;
                    matchedList.Remove(match);
                }
                else
                {
                    match.ExType = ExecutionType.Partial;
                    match.QtyTraded = ordered;
                    var index = matchedList.IndexOf(match);
                    match.Quantity -= match.QtyTraded;
                    matchedList[index] = match;
                }
                
                BroadcastOrder(match);

                available -= match.QtyTraded;
                ordered -= match.QtyTraded;
                if (available <= 0 || ordered <= 0) break;
            }
            transactionNo++;

            var list = buyOrder ? BuyOrders : SellOrders;
            var o = buyOrder ? list.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : list.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();

            if (ordered > 0)
            {
                order.Quantity = ordered - available;
                switch (order.Action)
                {
                    case Data.Action.Add:
                        order.Action = Data.Action.Add;
                        AddNewOrder(list, order);
                        orderNo++;
                        break;

                    case Data.Action.Modify:
                        order.Action = Data.Action.Modify;
                        var index = list.IndexOf(o);
                        o.Quantity = order.Quantity;
                        o.Price = order.Price;
                        list[index] = o;
                        BroadcastOrder(order);
                        break;
                }
            }
            else
            {
                switch (order.Action)
                {
                    case Data.Action.Add: orderNo++; break;
                    case Data.Action.Modify:
                        list.Remove(o);
                        order.Action = Data.Action.Delete;
                        BroadcastOrder(order);
                        break;
                }
            }

        }

        bool IsReady4Execution(AsyncObsetion<AllOrder> orderList, AllOrder order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var o = buyOrder ? orderList.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : orderList.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();

            if (o != null)
            {
                var index = orderList.IndexOf(o);
                o.Quantity = order.Quantity;
                o.Price = order.Price;
                orderList[index] = o;

                if (Match4Execution(order).Count() > 0) return true;
                else
                {
                    BroadcastOrder(order);
                    return false;
                }
            }
            else return false;
        }

        IEnumerable<AllOrder> Match4Execution(AllOrder order)
        {
            var match = order.OrderType == OrderType.Buy ? SellOrders.Where(x => x.ItemCode == order.ItemCode && x.Price <= order.Price)
                                                      : BuyOrders.Where(x => x.ItemCode == order.ItemCode && x.Price >= order.Price);
            return match;
        }

        void DeleteIfExistis(AsyncObsetion<AllOrder> orderList, AllOrder order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
            var o = buyOrder ? orderList.Where(x => x.BuyOrderNo == order.BuyOrderNo).FirstOrDefault()
                             : orderList.Where(x => x.SellOrderNo == order.SellOrderNo).FirstOrDefault();
            if (o != null)
            {
                orderList.Remove(o);
                BroadcastOrder(order);
            }
        }

        void AddNewOrder(AsyncObsetion<AllOrder> orderList, AllOrder order)
        {
            bool buyOrder = order.OrderType == OrderType.Buy;
        
            order.BuyOrderNo = buyOrder ? orderNo : 0;
            order.SellOrderNo = buyOrder ? 0 : orderNo;

            orderList.Add(order);
            BroadcastOrder(order);
        }

        void BroadcastOrder(AllOrder order)
        {
            var array = PacMan<AllOrder>.PackOrder(order);
            if (order.Action == Data.Action.Execute) ExecutedArray.Add(array);
            var msg = new List<ArraySegment<byte>>()
            {
                PacMan<MessageHeader>.Pack(new MessageHeader() { Type = Message.Trade }),
                array
            };

            Parallel.ForEach(Clients, c =>
            {
                try { c.SendArgs.AcceptSocket.Send(msg); }
                catch (Exception) { }
            });
        }

        void BroadcastNews(byte[] array)
        {
            for (int i = 0; i < array.Length; i += Constants.newsSize)
            {
                NewsArray.Add(array.Skip(i).Take(Constants.newsSize).ToArray());
            }

            var msg = new List<ArraySegment<byte>>()
            {
                PacMan<MessageHeader>.Pack(new MessageHeader() { Type = Message.News, Size = array.Length }),
                array
            };

            Parallel.ForEach(Clients, c =>
            {
                try{ c.SendArgs.AcceptSocket.Send(msg); }
                catch (Exception) { }
            });
        }

        void Sent(object s, SocketAsyncEventArgs e)
        {
            if (e.SocketError == SocketError.Success)
            {

            }
            else RemoveClient(e);
        }

        void RemoveClient(SocketAsyncEventArgs e)
        {
            var c = Clients.FirstOrDefault(x => x.SendArgs == e || x.RecvArgs == e);
            Cleanup(c);
            Clients.Remove(c);
        }

        void StopServer(object obj)
        {
            DisposeClients();
            server.Close();
            server.Dispose();
            IsListening = false;
            Status = "Start Server";
        }

        void DisposeClients()
        {
            if (Clients.Count > 0)
            {
                foreach (var c in Clients) Cleanup(c);
                Clients.Clear();
            }
        }

        void Cleanup(Client c)
        {
            if (c.SendArgs != null)
            {
                c.SendArgs.AcceptSocket.Close();
                c.SendArgs.AcceptSocket.Dispose();
                c.SendArgs.Dispose();
            }

            if (c.RecvArgs != null)
            {
                c.RecvArgs.AcceptSocket.Close();
                c.RecvArgs.AcceptSocket.Dispose();
                c.RecvArgs.Dispose();
            }
        }

        void SetBuffer(SocketAsyncEventArgs e, int length) => e.SetBuffer(new byte[length], 0, length);

        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class Client
    {
        public string Name { get; set; }
        public SocketAsyncEventArgs SendArgs { get; set; }
        public SocketAsyncEventArgs RecvArgs { get; set; }
    }

    public class FixedBuffers
    {
        public byte[] OrderBuffer { get; set; }
        public byte[] HeaderBuffer { get; set; }

        public FixedBuffers()
        {
            OrderBuffer = new byte[Constants.orderSize];
            HeaderBuffer = new byte[Constants.messageHeaderLength];
        }
    }

    public class Command : ICommand
    {
        Action<object> Do;
        Func<object, bool> CanDo;

        public Command(Action<object> Do, Func<object, bool> CanDo)
        {
            this.CanDo = CanDo;
            this.Do = Do;
            CommandManager.RequerySuggested += (o, e) => Changed();
        }

        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter) => CanDo(parameter);
        public void Execute(object parameter) => Do(parameter);
        public void Changed() => CanExecuteChanged?.Invoke(null, EventArgs.Empty);
    }
}
