﻿namespace Data
{
    public class Constants
    {
        public static int tradePort = 65535;
        public static int filePort = 65534;
        public static int infoBuffLength = 13;
        public static int fileInfoBuffLength = 128;
        public static int itemSize = 454;
        public static int orderSize = 88;
        public static int newsSize = 1024;
        public static int messageHeaderLength = 8;
        public static int headerSize = 36;

        public static string host = "127.0.0.1";
    }
}
