﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Data
{
    public class Item : INotifyPropertyChanged
    {
        int id;
        public int Id { get => id; set { id = value; OnPropertyChanged(); } }

        string name;
        public string Name { get => name; set { name = value; OnPropertyChanged(); } }

        float cap;
        public float Cap { get => cap; set { cap = value; OnPropertyChanged(); } }

        float mid;
        public float Mid { get => mid; set { mid = value; OnPropertyChanged(); } }

        float floor;
        public float Floor { get => floor; set { floor = value; OnPropertyChanged(); } }

        int securities;
        public int Securities { get => securities; set { securities = value; OnPropertyChanged(); } }

        float owners;
        public float Owners { get => owners; set { owners = value; OnPropertyChanged(); } }

        float govt;
        public float Govt { get => govt; set { govt = value; OnPropertyChanged(); } }

        float institutions;
        public float Institutions { get => institutions; set { institutions = value; OnPropertyChanged(); } }

        float foreign;
        public float Foreign { get => foreign; set { foreign = value; OnPropertyChanged(); } }

        float @public;
        public float Public { get => @public; set { @public = value; OnPropertyChanged(); } }

        List<PerSecurityFinancials> perSecurity;
        public List<PerSecurityFinancials> PerSecurity { get => perSecurity; set { perSecurity = value; OnPropertyChanged(); } }

        List<Dividend> dividends;
        public List<Dividend> Dividends { get => dividends; set { dividends = value; OnPropertyChanged(); } }


        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class AllOrder : INotifyPropertyChanged, ICloneable
    {

        string executionTime;
        public string ExecutionTime { get => executionTime; set { executionTime = value; OnPropertyChanged(); } }

        sbyte upDownOrNone;
        public sbyte UpDownOrNone { get => upDownOrNone; set { upDownOrNone = value; OnPropertyChanged(); } }

        int transactionNo;
        public int TransactionNo { get => transactionNo; set { transactionNo = value; OnPropertyChanged(); } }

        int buyOrderNo;
        public int BuyOrderNo { get => buyOrderNo; set { buyOrderNo = value; OnPropertyChanged(); } }

        int sellOrderNo;
        public int SellOrderNo { get => sellOrderNo; set { sellOrderNo = value; OnPropertyChanged(); } }

        Action action;
        public Action Action { get => action; set { action = value; OnPropertyChanged(); } }

        int itemCode;
        public int ItemCode { get => itemCode; set { itemCode = value; OnPropertyChanged(); } }

        string itemName;
        public string ItemName { get => itemName; set { itemName = value; OnPropertyChanged(); } }


        OrderType orderType;
        public OrderType OrderType { get => orderType; set { orderType = value; OnPropertyChanged(); } }

        int quantity;
        public int Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }

        float price;
        public float Price { get => price; set { price = value; OnPropertyChanged(); } }

        int partyCode;
        public int PartyCode { get => partyCode; set { partyCode = value; OnPropertyChanged(); } }

        string brokerName;
        public string BrokerName { get => brokerName; set { brokerName = value; OnPropertyChanged(); } }

        string brokerBought;
        public string BrokerBought { get => brokerBought; set { brokerBought = value; OnPropertyChanged(); } }

        string brokerSold;
        public string BrokerSold { get => brokerSold; set { brokerSold = value; OnPropertyChanged(); } }

        int partyBought;
        public int PartyBought { get => partyBought; set { partyBought = value; OnPropertyChanged(); } }

        int partySold;
        public int PartySold { get => partySold; set { partySold = value; OnPropertyChanged(); } }

        int qtyTraded;
        public int QtyTraded { get => qtyTraded; set { qtyTraded = value; OnPropertyChanged(); } }


        ExecutionType exType;
        public ExecutionType ExType { get => exType; set { exType = value; OnPropertyChanged(); } }



        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion

        public object Clone() => this.MemberwiseClone();
    }

    public class DisplayOrder : INotifyPropertyChanged
    {

        int noOfOrder;
        public int NoOfOrder { get => noOfOrder; set { noOfOrder = value; OnPropertyChanged(); } }

        int quantity;
        public int Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }


        float price;
        public float Price { get => price; set { price = value; OnPropertyChanged(); } }


        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class DisplayPending : INotifyPropertyChanged
    {

        int partyCode;
        public int PartyCode { get => partyCode; set { partyCode = value; OnPropertyChanged(); } }

        string itemName;
        public string ItemName { get => itemName; set { itemName = value; OnPropertyChanged(); } }

        int itemCode;
        public int ItemCode { get => itemCode; set { itemCode = value; OnPropertyChanged(); } }

        string orderType;
        public string OrderType { get => orderType; set { orderType = value; OnPropertyChanged(); } }

        int orderNo;
        public int OrderNo { get => orderNo; set { orderNo = value; OnPropertyChanged(); } }

        int quantity;
        public int Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }

        float price;
        public float Price { get => price; set { price = value; OnPropertyChanged(); } }

        float cap;
        public float Cap { get => cap; set { cap = value; OnPropertyChanged(); } }

        float floor;
        public float Floor { get => floor; set { floor = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class DisplayExecuted : INotifyPropertyChanged, ICloneable
    {

        int transactionNo;
        public int TransactionNo { get => transactionNo; set { transactionNo = value; OnPropertyChanged(); } }

        string type;
        public string Type { get => type; set { type = value; OnPropertyChanged(); } }

        int partyCode;
        public int PartyCode { get => partyCode; set { partyCode = value; OnPropertyChanged(); } }

        string itemName;
        public string ItemName { get => itemName; set { itemName = value; OnPropertyChanged(); } }

        int itemCode;
        public int ItemCode { get => itemCode; set { itemCode = value; OnPropertyChanged(); } }

        int buyOrderNo;
        public int BuyOrderNo { get => buyOrderNo; set { buyOrderNo = value; OnPropertyChanged(); } }

        int sellOrderNo;
        public int SellOrderNo { get => sellOrderNo; set { sellOrderNo = value; OnPropertyChanged(); } }

        int qtyTraded;
        public int QtyTraded { get => qtyTraded; set { qtyTraded = value; OnPropertyChanged(); } }

        float price;
        public float Price { get => price; set { price = value; OnPropertyChanged(); } }

        string toFromBroker;
        public string ToFromBroker { get => toFromBroker; set { toFromBroker = value; OnPropertyChanged(); } }

        int toFromParty;
        public int ToFromParty { get => toFromParty; set { toFromParty = value; OnPropertyChanged(); } }


        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion

        public object Clone() => this.MemberwiseClone();
    }

    public class DisplayNews : INotifyPropertyChanged
    {
        string time;
        public string Time { get => time; set { time = value; OnPropertyChanged(); } }

        int itemCode;
        public int ItemCode { get => itemCode; set { itemCode = value; OnPropertyChanged(); } }

        string itemName;
        public string ItemName { get => itemName; set { itemName = value; OnPropertyChanged(); } }

        string feed;
        public string Feed { get => feed; set { feed = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class NewsItem : INotifyPropertyChanged
    {
        string itemName;
        public string ItemName { get => itemName; set { itemName = value; OnPropertyChanged(); } }

        string newsFinal;
        public string NewsFinal { get => newsFinal; set { newsFinal = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class FHLLV : INotifyPropertyChanged
    {
        float first;
        public float First { get => first; set { first = value; OnPropertyChanged(); } }

        float high;
        public float High { get => high; set { high = value; OnPropertyChanged(); } }

        float low;
        public float Low { get => low; set { low = value; OnPropertyChanged(); } }

        float last;
        public float Last { get => last; set { last = value; OnPropertyChanged(); } }

        int volume;
        public int Volume { get => volume; set { volume = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class TradeByCustomer : INotifyPropertyChanged
    {
        int transNo;
        public int TransNo { get => transNo; set { transNo = value; OnPropertyChanged(); } }

        int orderNo;
        public int OrderNo { get => orderNo; set { orderNo = value; OnPropertyChanged(); } }

        string type;
        public string Type { get => type; set { type = value; OnPropertyChanged(); } }

        float price;
        public float Price { get => price; set { price = value; OnPropertyChanged(); } }

        int quantity;
        public int Quantity { get => quantity; set { quantity = value; OnPropertyChanged(); } }

        decimal valueTraded;
        public decimal ValueTraded { get => valueTraded; set { valueTraded = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class SumBy : INotifyPropertyChanged
    {
        string name;
        public string Name { get => name; set { name = value; OnPropertyChanged(); } }

        int buys;
        public int Buys { get => buys; set { buys = value; OnPropertyChanged(); } }

        int sells;
        public int Sells { get => sells; set { sells = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class PVSeries : INotifyPropertyChanged
    {

        float previousPrice;
        public float PreviousPrice { get => previousPrice; set { previousPrice = value; OnPropertyChanged(); } }

        float currentPrice;
        public float CurrentPrice { get => currentPrice; set { currentPrice = value; OnPropertyChanged(); } }

        int volume;
        public int Volume { get => volume; set { volume = value; OnPropertyChanged(); } }

        string executionTime;
        public string ExecutionTime { get => executionTime; set { executionTime = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class PerSecurityFinancials : INotifyPropertyChanged
    {

        string yq;
        public string YQ { get => yq; set { yq = value; OnPropertyChanged(); } }

        float eps;
        public float EPS { get => eps; set { eps = value; OnPropertyChanged(); } }

        float nav;
        public float NAV { get => nav; set { nav = value; OnPropertyChanged(); } }

        //cash & Cash equivalents
        float cash;
        public float Cash { get => cash; set { cash = value; OnPropertyChanged(); } }

        float debt;
        public float Debt { get => debt; set { debt = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }


    public class Dividend : INotifyPropertyChanged
    {
        int year;
        public int Year { get => year; set { year = value; OnPropertyChanged(); } }

        float cash;
        public float Cash { get => cash; set { cash = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
