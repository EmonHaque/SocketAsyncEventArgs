﻿using Data;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Data;

namespace Client.VMs
{
    public class ChartsVM : INotifyPropertyChanged
    {
        double secondLine, thirdLine, fourthLine;
        int secondText, thirdText, fourthText;
        

        public double SecondLine { get => secondLine; set { secondLine = value; OnPropertyChanged(); } }
        public double ThirdLine { get => thirdLine; set { thirdLine = value; OnPropertyChanged(); } }
        public double FourthLine { get => fourthLine; set { fourthLine = value; OnPropertyChanged(); } }
        public int SecondText { get => secondText; set { secondText = value; OnPropertyChanged(); } }
        public int ThirdText { get => thirdText; set { thirdText = value; OnPropertyChanged(); } }
        public int FourthText { get => fourthText; set { fourthText = value; OnPropertyChanged(); } }
        

        public Command Resized { get; set; }

        public ChartsVM()
        {
            Resized = new Command(resized, (o) => true);
            OrderVM.CurrentExecuted.CollectionChanged += UpdateLineTexts;
            setLabels(300);
        }

        void UpdateLineTexts(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                var order = e.NewItems[0] as PVSeries;
                if (order.Volume > FourthText) setLabels(order.Volume);
            }
            else if (e.Action == NotifyCollectionChangedAction.Reset) setLabels(300);
        }

        void setLabels(int max)
        {
            FourthText = max;
            ThirdText = max / 3 * 2;
            SecondText = max / 3;
        }

        void resized(object obj)
        {
            var height = (double)obj;
            FourthLine = height;
            ThirdLine = height / 3 * 2;
            SecondLine = height / 3;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }

    public class VolumeConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var height = (double)values[0];
            var currentMax = (int)values[1];
            var volume = (int)values[2];
            return volume * height / currentMax;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class PriceConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var price = (float)values[0];
            var cap = (float)values[1];
            var floor = (float)values[2];
            var height = (double)values[3];

            var remainingHeight = height - height / 3;
            var range = cap - floor;
            return (height / 3) + ((price - floor) * remainingHeight / range);
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
