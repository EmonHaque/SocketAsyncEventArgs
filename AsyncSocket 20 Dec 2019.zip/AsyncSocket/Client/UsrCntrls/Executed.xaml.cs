﻿using System.Windows.Controls;

namespace Client.UsrCntrls
{
    /// <summary>
    /// Interaction logic for Executed.xaml
    /// </summary>
    public partial class Executed : UserControl
    {
        public Executed()
        {
            InitializeComponent();
        }
    }
}
